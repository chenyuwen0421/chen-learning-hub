const courses = [
  ['optimization', '最优化方法导论'],
  ['probability', '概率统计'],
  ['systems', '计算机系统实验室'],
  ['llm', 'LLM Math Lab'],
];

const current = document.body.dataset.hubCourse;
const hubRoot = new URL('../', import.meta.url);
const icon = '<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.75"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>';

function mountSwitcher() {
  const actions = document.querySelector('header .header-actions');
  if (!actions) return false;

  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = 'hub-switch';
  trigger.setAttribute('aria-label', '全部课程');
  trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.title = '全部课程';
  trigger.innerHTML = icon + '<span>全部课程</span>';

  const dialog = document.createElement('dialog');
  dialog.className = 'hub-dialog';
  dialog.setAttribute('aria-labelledby', 'hub-dialog-title');
  dialog.innerHTML = '<div class="hub-dialog-head"><h2 id="hub-dialog-title">全部课程</h2><form method="dialog"><button type="submit" aria-label="关闭" autofocus>×</button></form></div>';
  const nav = document.createElement('nav');
  nav.setAttribute('aria-label', '课程切换');
  for (const [id, title] of courses) {
    const link = document.createElement('a');
    link.href = new URL(id + '/', hubRoot).href;
    link.textContent = title;
    if (id === current) link.setAttribute('aria-current', 'page');
    nav.append(link);
  }
  const home = document.createElement('a');
  home.href = hubRoot.href;
  home.className = 'hub-home';
  home.textContent = '返回课程总览';
  dialog.append(nav, home);
  document.body.append(dialog);

  trigger.addEventListener('click', () => dialog.showModal());
  actions.prepend(trigger);
  return true;
}

if (!mountSwitcher()) {
  const root = document.getElementById('root');
  if (root) {
    const observer = new MutationObserver(() => {
      if (mountSwitcher()) observer.disconnect();
    });
    observer.observe(root, { childList: true, subtree: true });
  }
}

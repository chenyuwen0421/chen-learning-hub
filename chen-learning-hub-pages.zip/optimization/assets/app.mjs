import {mountFigure,saveFigure} from './figures/mount.mjs';

const NAME='最优化方法导论', STORAGE='optimization:learning:v1';
const reading=document.getElementById('reading'), sidebar=document.getElementById('sidebar'),
  toc=document.getElementById('toc'), menu=document.getElementById('menu'),
  figureDialog=document.getElementById('figure-modal'), fileInput=document.getElementById('progress-file');
const esc = value => String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const icons={
  light:'<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M20.6 14.3A8.75 8.75 0 0 1 9.7 3.4 8.85 8.85 0 1 0 20.6 14.3Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
  dark:'<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>'
};
const groupNames=['起步','求解','重写','证明最好','推广与合流','附录'];
const chapterCache=new Map();
let index=[],figures={},course=null,section=null,review=false,revision=0,returnTo=null,moved=null;
let progress = {done:{},flags:{},notes:{},last:null};
let pendingFocus=null;
try { progress={...progress,...JSON.parse(localStorage.getItem(STORAGE)||'{}')}; } catch {}
const persist=()=>{try {localStorage.setItem(STORAGE,JSON.stringify(progress));}catch {}};
const chapterLink=(id,n=0,target='')=>'#'+id+'/'+n+(target?'/'+target:'');
function sectionLabel(s){return s.titleHTML || '导读';}
function lookup(chapter){return index.find(c=>c.id===chapter);}
function route() {
  const [page='home',part='0',target='']=location.hash.slice(1).split('/');
  const c=lookup(page);
  if(!c)return {page:['home','checks','figures'].includes(page)?page:'home',n:0,target};
  const mapped=c.sections.findIndex(s=>s.id===part);
  return {page,n:mapped>=0?mapped:Math.min(Math.max(0,parseInt(part,10)||0),c.sections.length-1),target};
}
async function data(path){
  const response=await fetch(new URL('../content/'+path+'.json',import.meta.url));
  if(!response.ok)throw Error('课程加载失败');
  return response.json();
}
function theme() {
  const mode=document.documentElement.dataset.theme==='dark'?'dark':'light';
  const button=document.querySelector('.theme-toggle');button.innerHTML=icons[mode];
  button.setAttribute('aria-label',mode==='dark'?'切换浅色模式':'切换深色模式');
  document.querySelector('meta[name="theme-color"]').content=mode==='dark'?'#121b28':'#ffffff';
}
function nav() {
  const pos=route();
  let previous=0;
  const top='<div class="nav-shortcuts">'+[
    ['home','课程总览','▤'],['checks','章节自查','✓'],['figures','图像目录','⌗']
  ].map(([id,text,icon])=>'<a href="#'+id+'" class="'+(pos.page===id?'current':'')+
    '"><span aria-hidden="true">'+icon+'</span>'+text+'</a>').join('')+'</div>';
  const list=index.map(c=>{
    const active=pos.page===c.id;
    let prefix='';
    if(previous!==c.part){previous=c.part;prefix='<h2 class="nav-label">'+groupNames[c.part-1]+'</h2>';}
    const children=active?'<div class="layer-nav">'+c.sections.map((s,n)=>
      '<a href="'+chapterLink(c.id,n)+'" class="'+(pos.n===n?'current':'')+'"'+(pos.n===n?' aria-current="page"':'')+
      '><span aria-hidden="true">'+(progress.done[s.id]?'✓':String(n+1).padStart(2,'0'))+'</span><span>'+
      sectionLabel(s)+'</span></a>').join('')+'</div>':'';
    return prefix+'<a class="course-nav'+(active?' current':'')+'" href="'+chapterLink(c.id)+'"><span class="nav-number">'+
      c.id+'</span><span>'+esc(c.short)+'</span></a>'+children;
  }).join('');
  return '<nav>'+top+list+'</nav>';
}

function overview() {
  const lead=index[0];
  let previous=0;
  return '<div class="overview-hero"><span class="eyebrow">课程总览</span><h1>'+NAME+'</h1><p>'+
    lead.titleHTML+'</p><div class="hero-actions"><a class="primary" href="'+chapterLink('00')+
    '">从序章开始 <span aria-hidden="true">→</span></a>'+
    (progress.last&&lookup(progress.last.chapter)?'<a class="button" href="'+chapterLink(progress.last.chapter,progress.last.section)+'">继续上次阅读</a>':'')+
    '</div></div><div class="course-list">'+index.map(c=>{
      const header=previous!==c.part?'<h2 class="part-heading">'+c.partHTML+'</h2>':'';
      previous=c.part;
      const done=c.sections.filter(s=>progress.done[s.id]).length;
      return header+'<a href="'+chapterLink(c.id)+'" class="course-card"><span class="course-no">'+c.id+
        '</span><strong>'+esc(c.short)+'</strong><span class="course-count">'+(done?'✓ '+done+' / ':'')+
        c.sections.length+' 节</span><span class="course-arrow" aria-hidden="true">→</span></a>';
    }).join('')+'</div>';
}
function catalogue(type) {
  const isFigures=type==='figures';
  return '<h1>'+(isFigures?'图像目录':'章节自查')+'</h1>'+index.map(c=>{
    const items=isFigures?Object.entries(figures).filter(([,f])=>f.chapter===c.id).map(([id,f])=>{
      const s=c.sections.find(s=>s.id===f.section);
      return '<a href="'+chapterLink(c.id,s.index,'fig-'+id)+'"><b>图 '+id+'</b><span>'+sectionLabel(s)+'</span><span aria-hidden="true">→</span></a>';
    }):c.sections.filter(s=>s.answers>0).map(s=>'<a href="'+chapterLink(c.id,s.index)+'"><span>'+sectionLabel(s)+
      '</span><span aria-hidden="true">→</span></a>');
    return items.length?'<section class="catalogue-group"><h2>'+c.titleHTML+'</h2>'+items.join('')+'</section>':'';
  }).join('');
}

function sectionHTML(s) {
  const {id}=s, done=!!progress.done[id], flag=!!progress.flags[id];
  return '<section class="reading-section" id="'+id+'">'+(s.titleHTML?'<h2>'+s.titleHTML+'</h2>':'')+
    '<div class="source-prose">'+s.html+'</div><div class="section-actions">'+
    '<button type="button" data-progress="done" data-section="'+id+'" aria-pressed="'+done+'">'+(done?'✓ 已掌握':'标记已掌握')+
    '</button><button type="button" data-progress="flags" data-section="'+id+'" aria-pressed="'+flag+'">'+(flag?'✓ 已标记疑问':'标记疑问')+
    '</button></div><details class="notes"><summary>我的思考与疑问</summary><textarea data-note="'+id+
    '" aria-label="本节笔记" placeholder="记下你自己的思路">'+esc(progress.notes[id])+'</textarea></details></section>';
}
function sectionPage(c,s) {
  const current=route(), next=index[index.indexOf(lookup(c.id))+1];
  const previous=s.index>0?chapterLink(c.id,s.index-1):null;
  const forward=s.index+1<c.sections.length?chapterLink(c.id,s.index+1):next?chapterLink(next.id):'#home';
  const partFirst=c.sections[0]?.lead && (review||s.lead);
  const part=partFirst?sectionHTML(c.sections[0]):'';
  const rest=review?c.sections.filter(x=>!x.lead).map(sectionHTML).join(''):s.lead?'':sectionHTML(s);
  const back=returnTo?'<button type="button" class="return-banner" data-command="back">← 返回刚才的阅读位置</button>':'';
  return back+part+'<header class="reading-head"><div class="eyebrow">'+
    (c.id==='00'?'序章':/^[ABC]$/.test(c.id)?'附录 '+c.id:'第 '+c.id+' 章')+
    ' <span aria-hidden="true">·</span> '+(review?'全章阅读':(current.n+1)+' / '+c.sections.length)+'</div>'+
    '<h1>'+c.titleHTML+'</h1></header>'+rest+
    '<nav class="page-turn" aria-label="翻页">'+(previous&&!review?'<a class="button" href="'+previous+'">← 上一节</a>':
      '<a class="button" href="#home">课程总览</a>')+'<a class="primary" href="'+(review?(next?chapterLink(next.id):'#home'):forward)+'">'+
      (!review&&s.index+1<c.sections.length?'进入下一节':next?'继续下一章':'返回课程总览')+' →</a></nav>';
}

function sideOutline(c,s) {
  if(!c) return '<div class="toc-label">阅读工具</div><button data-command="search">查找章节、概念或公式</button><button data-command="tools">学习进度与打印</button>';
  return '<div class="toc-label">本章路线</div><nav>'+c.sections.map((part,n)=>
    '<a class="'+(part.id===s.id?'current':'')+'" href="'+chapterLink(c.id,n)+'">'+sectionLabel(part)+'</a>').join('')+
    '</nav><div class="toc-tools"><button data-command="review">'+(review?'分节阅读':'全章阅读')+
    '</button><button data-command="print">打印当前阅读</button><button data-command="download">导出学习进度</button></div>';
}

function jumpTo(id) {
  if(!id)return;
  requestAnimationFrame(()=>document.getElementById(id)?.scrollIntoView({block:'start',behavior:'instant'}));
}
function sectionAnchor(id,n,target=''){
  return chapterLink(id,n,target);
}
function linkOriginalReferences() {
  for(const block of reading.querySelectorAll('.source-prose')){
    const walker=document.createTreeWalker(block,NodeFilter.SHOW_TEXT);
    const nodes=[];
    while(walker.nextNode()) {
      const node=walker.currentNode;
      if(!node.parentElement.closest('.katex,a,summary,code,h3,h4')) nodes.push(node);
    }
    const refs=/附录\s*([ABC])[.．]?\s*([1-7])|图\s*(\d{1,2})-(\d)\b/g;
    for(const node of nodes){
      const txt=node.nodeValue;
      let part=0, match, fragment=null;
      refs.lastIndex=0;
      while((match=refs.exec(txt))){
        let href='';
        if(match[1]){
          const ch=lookup(match[1]),s=ch?.sections.find(s=>s.id===match[1]+'-'+match[1]+match[2]);
          if(s) href=sectionAnchor(ch.id,s.index);
        }else{
          const id=match[3].padStart(2,'0')+'-'+match[4],f=figures[id];
          const s=lookup(f?.chapter)?.sections.find(s=>s.id===f?.section);
          if(s) href=sectionAnchor(f.chapter,s.index,'fig-'+id);
        }
        if(!href)continue;
        fragment??=document.createDocumentFragment();
        fragment.append(txt.slice(part,match.index));
        const a=document.createElement('a');
        a.href=href;a.textContent=match[0];a.dataset.crossref='yes';fragment.append(a);
        part=refs.lastIndex;
      }
      if(fragment){fragment.append(txt.slice(part));node.replaceWith(fragment);}
    }
  }
}
const lazy = new IntersectionObserver(entries=>{
  for(const entry of entries){
    if(!entry.isIntersecting)continue;
    lazy.unobserve(entry.target);
    void mountFigure(entry.target,figures[entry.target.dataset.figure]).catch(error=>{
      console.error(error);
      entry.target.textContent='图像加载失败，请刷新后重试。';
    });
  }
},{rootMargin:'500px'});
// KaTeX can wrap between operators. Give indivisible wide expressions their own
// scroll area only when a single base is wider than its containing paragraph.
function fitMath() {
  const changes=[];
  for(const inline of reading.querySelectorAll('.formula-inline')){
    const box=inline.closest('p,li,td,th,h2,h3,h4');
    const room=box?.clientWidth || reading.clientWidth;
    if(room===0)continue;
    const wide=[...inline.querySelectorAll('.katex-html > .base')].some(b=>b.getBoundingClientRect().width>room-2);
    changes.push([inline,wide]);
  }
  for(const [inline,wide] of changes)inline.classList.toggle('math-scroll',wide);
}
let mathFrame;
function scheduleFitMath() {
  cancelAnimationFrame(mathFrame);
  mathFrame=requestAnimationFrame(fitMath);
}
let readingWidth=0;
new ResizeObserver(([entry])=>{
  if(entry.contentRect.width!==readingWidth){
    readingWidth=entry.contentRect.width;
    scheduleFitMath();
  }
}).observe(reading);
document.fonts.ready.then(scheduleFitMath);
reading.addEventListener('toggle',event=>{
  if(event.target.matches('.authored-answer,.visual-alt')&&event.target.open)scheduleFitMath();
},true);
function attachFigures() {
  lazy.disconnect();
  for(const el of reading.querySelectorAll('[data-figure]'))lazy.observe(el);
}
async function render({scroll=true}={}) {
  const ticket=++revision, pos=route(), c=lookup(pos.page);
  if(c) {
    if(!chapterCache.has(c.id)){
      chapterCache.set(c.id,data(c.id).catch(error=>{chapterCache.delete(c.id);throw error;}));
    }
    const full=await chapterCache.get(c.id);
    if(ticket!==revision)return;
    course=full;section=full.sections[pos.n];
    progress.last={chapter:c.id,section:pos.n};persist();
    reading.innerHTML=sectionPage(full,section);
    linkOriginalReferences();attachFigures();scheduleFitMath();
  } else {
    lazy.disconnect();course=section=null;
    reading.innerHTML=pos.page==='home'?overview():catalogue(pos.page);
  }
  const navScroll=sidebar.scrollTop;
  sidebar.innerHTML=nav();sidebar.scrollTop=navScroll;
  toc.innerHTML=sideOutline(course,section);
  document.getElementById('mobile-title').textContent=course?.short??({home:'课程总览',checks:'章节自查',figures:'图像目录'}[pos.page]);
  const reviewButton=document.querySelector('.chapter-view');
  reviewButton.hidden=!course;reviewButton.textContent=review?'分节阅读':'全章阅读';
  document.title=course?course.title+' · '+NAME:NAME;
  if(pendingFocus!==null){window.scrollTo(0,pendingFocus);pendingFocus=null;}
  else if(scroll&&!pos.target)window.scrollTo(0,0);
  if(scroll&&pos.target)jumpTo(pos.target);
}
function renderOrReport(options) {
  void render(options).catch(error=>{
    console.error(error);reading.innerHTML='<p role="alert">课程加载失败，请刷新后重试。</p>';
  });
}
function openMenu(title,html) {
  menu.querySelector('h2').textContent=title;
  menu.querySelector('.modal-content').innerHTML=html;
  if(!menu.open)menu.showModal();
}
function searchMenu() {
  openMenu('查找章节、概念或公式','<label class="search-label"><span class="sr-only">搜索课程</span>'+
    '<input class="search-input" type="search" placeholder="例如：投影、次水平集、KKT" autocomplete="off"></label><div class="search-results"></div>');
  const input=menu.querySelector('input');
  input.addEventListener('input',()=>{
    const key=input.value.trim().toLowerCase(),results=menu.querySelector('.search-results');
    if(!key){results.replaceChildren();return;}
    const rows=[];
    for(const c of index)for(const s of c.sections){
      const searchable=(s.title+' '+s.text).toLowerCase(),p=searchable.indexOf(key);
      if(p>=0)rows.push({c,s,priority:s.title.toLowerCase().includes(key)?0:1,p});
    }
    rows.sort((a,b)=>a.priority-b.priority||a.p-b.p);
    results.innerHTML=rows.slice(0,40).map(({c,s})=>
      '<a href="'+chapterLink(c.id,s.index)+'"><b>'+esc(c.id)+' · '+sectionLabel(s)+'</b></a>'
    ).join('')||'<p>没有找到相关内容。</p>';
  });
  input.focus();
}
function toolsMenu() {
  openMenu('阅读工具','<div class="reading-tools">'+(course?
    '<button data-command="review">'+(review?'分节阅读':'全章阅读')+'</button>':'')+
    '<button data-command="search">查找章节、概念或公式</button><button data-command="print">打印当前阅读</button>'+
    '<button data-command="download">导出学习进度</button><button data-command="upload">导入学习进度</button>'+
    '<button data-command="theme">切换深浅主题</button></div>');
}
function openFigure(button){
  const original=button.closest('[data-figure]');if(!original)return;
  const figure=original.firstElementChild;
  moved={original,figure,button};
  figureDialog.querySelector('h2').textContent='图 '+original.dataset.figure;
  figureDialog.dataset.figureId=original.dataset.figure;
  figureDialog.querySelector('.modal-content').append(figure);
  button.hidden=true;figureDialog.showModal();
}
figureDialog.addEventListener('close',()=>{
  if(!moved)return;
  moved.original.append(moved.figure);moved.button.hidden=false;
  if(moved.button.isConnected)moved.button.focus({preventScroll:true});
  moved=null;
});

function download() {
  const blob=new Blob([JSON.stringify({schema:1,course:'optimization-methods',state:progress},null,2)],{type:'application/json'});
  const link=document.createElement('a');link.href=URL.createObjectURL(blob);
  link.download='optimization-learning-progress.json';link.click();
  setTimeout(()=>URL.revokeObjectURL(link.href),1000);
}
fileInput.addEventListener('change',async()=>{
  const file=fileInput.files[0];
  if(!file)return;
  try {
    const incoming=JSON.parse(await file.text());
    if(incoming.schema!==1||incoming.course!=='optimization-methods'||!incoming.state)throw Error('请选择本课程导出的进度文件');
    const {state}=incoming;
    const known=new Set(index.flatMap(c=>c.sections.map(s=>s.id)));
    for(const [key,kind] of [['done','boolean'],['flags','boolean'],['notes','string']]){
      for(const [id,value] of Object.entries(state[key]||{}))
        if(known.has(id)&&typeof value===kind)progress[key][id]=value;
    }
    const c=lookup(state.last?.chapter);
    if(c&&Number.isInteger(state.last.section)&&c.sections[state.last.section])progress.last=state.last;
    persist();renderOrReport({scroll:false});openMenu('学习进度','<p role="status">学习进度已导入。</p>');
  } catch {
    openMenu('学习进度','<p role="alert">无法读取，请选择本课程导出的进度文件。</p>');
  }
  fileInput.value='';
});

document.addEventListener('click',event=>{
  const target=event.target.closest('button,a');
  if(!target)return;
  if(target.matches('.skip')){event.preventDefault();reading.focus();return;}
  if(target.matches('a[href^="#"]')){
    if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
    if(menu.open)menu.close();
    if(target.dataset.crossref==='yes')returnTo={hash:location.hash||'#home',scrollY:window.scrollY};
    if(target.hash===location.hash&&target.hash.split('/')[2])jumpTo(target.hash.split('/')[2]);
  }
  const category=target.dataset.progress;
  if(category){
    const id=target.dataset.section;
    progress[category][id]=!progress[category][id];
    target.setAttribute('aria-pressed',progress[category][id]);
    target.textContent=category==='done'?(progress.done[id]?'✓ 已掌握':'标记已掌握'):(progress.flags[id]?'✓ 已标记疑问':'标记疑问');
    persist();
    const previous=sidebar.scrollTop;sidebar.innerHTML=nav();sidebar.scrollTop=previous;
  }
  const command=target.dataset.command;
  if(command==='nav')openMenu('课程目录',nav());
  if(command==='search')searchMenu();
  if(command==='tools')toolsMenu();
  if(command==='close')menu.close();
  if(command==='close-figure')figureDialog.close();
  if(command==='expand-figure')openFigure(target);
  if(command==='svg'){
    const figure=target.closest('figure');
    saveFigure(figure,target.closest('[data-figure]')?.dataset.figure||figureDialog.dataset.figureId);
  }
  if(command==='theme'){
    const next=document.documentElement.dataset.theme==='dark'?'light':'dark';
    document.documentElement.dataset.theme=next;
    try{localStorage.setItem('optimization:theme',next);}catch{}
    theme();
  }
  if(command==='review'&&course){
    review=!review;if(menu.open)menu.close();renderOrReport();
  }
  if(command==='print'){if(menu.open)menu.close();window.print();}
  if(command==='upload')fileInput.click();
  if(command==='download')download();
  if(command==='back'&&returnTo){
    const {hash,scrollY}=returnTo;returnTo=null;pendingFocus=scrollY;
    if(hash===location.hash)renderOrReport();else location.hash=hash;
  }
});
document.addEventListener('input',event=>{
  const id=event.target.dataset.note;
  if(id){progress.notes[id]=event.target.value;persist();}
});
window.addEventListener('hashchange',()=>{
  review=false;if(menu.open)menu.close();if(figureDialog.open)figureDialog.close();renderOrReport();
});
theme();
try {
  [index,figures]=await Promise.all([data('index'),data('figures')]);
  renderOrReport();
} catch(error) {
  console.error(error);reading.innerHTML='<p role="alert">课程加载失败，请刷新后重试。</p>';
}

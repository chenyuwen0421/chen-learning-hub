import {C, above, boundary, chart, choice, circle, clamp, dot, fmt, labelMath as M, legend, levels,
  mix, model, norm, panel, perp, pi, plus, polar, preset, range, reading, seq, times, minus, unit, vec} from './plot.mjs';
import {mesh, spatial} from './space.mjs';
import {ridge, sampleX, sampleY, spectral, squaredError} from './regression.mjs';
import {hardPair, positive, softMargin} from './svm.mjs';

const xy={x:'x₁',y:'x₂',equal:true};
const rho15=1.5, w15=[2,1], a015=[.48,.3], U15=[[1.35,0],[0,.65]], x15=[2/1.35,1/.65];
const image15=u=>plus(a015,U15.map(row=>dot(row,u)));
const b15=dot(a015,x15)+rho15*norm(w15);
const rootAngle=Math.atan2(1,2);
const l1=[[1,0],[0,1],[-1,0],[0,-1]],linf=[[1,1],[-1,1],[-1,-1],[1,-1]];

function specNorm(B) {
  const {eigenvalues,vectors}=spectral(B);
  const i=Math.abs(eigenvalues[0])>=Math.abs(eigenvalues[1])?0:1;
  return {sigma:Math.abs(eigenvalues[i]), u:vectors[i]};
}
const matrix=(x,mode)=>mode==='rank'?[[x,0],[0,0]]:[[x,.65],[.65,.5-x]];
const mv=(A,v)=>A.map(row=>dot(row,v));
const lse=u=>Math.abs(u)+Math.log1p(Math.exp(-2*Math.abs(u)));

const ridgePoint=rho=>{
  const z=rho===Infinity?[0,0]:ridge(sampleX,sampleY,rho);
  return [squaredError(sampleX,sampleY,z),dot(z,z)/2];
};
const leftRidge=ridgePoint(0),rightRidge=ridgePoint(Infinity);
const pareto=[leftRidge,...seq(-4,4,120).map(p=>ridgePoint(10**p)),rightRidge];

export const advanced = {
  '15-1':model({theta:rootAngle+pi/2,r:rho15,zero:'no'},[
    range('theta','扰动方向（弧度）',0,2*pi,.01),range('r','扰动长度',0,rho15,.01),
    choice('zero','候选方案',[['no','固定方案 x'],['yes','零向量 x = 0']]),
    preset('钝角扰动',{theta:rootAngle+pi,r:rho15,zero:'no'}),
    preset('正交扰动',{theta:rootAngle+pi/2,r:rho15,zero:'no'}),
    preset('同向拉满',{theta:rootAngle,r:rho15,zero:'no'})
  ],s=>{
    const u=polar(s.theta,s.r),a=image15(u),x=s.zero==='yes'?[0,0]:x15,w=s.zero==='yes'?[0,0]:w15;
    return panel('扰动源空间',chart('欧氏圆盘内的扰动与最大化方向',[-2.65,2.65,-2.65,2.65],p=>{
      p.ring([0,0],rho15,C.blue,{fill:C.blue,opacity:.14});p.ring([0,0],rho15,C.blue);
      p.arrow([0,0],w,C.blue,2.7);p.arrow([0,0],u,C.red,3);
      if(norm(w))p.text(w,'w',C.blue,8,-10);
      p.dot(u,C.red,6,false,'u');p.text(u,'u',C.red,8,17);
    },{...xy,x:'u₁',y:'u₂'}),{key:'source',value:reading('u='+vec(u),'w^\\top u='+fmt(dot(w,u)))})+
    panel('系数空间',chart('仿射像椭球与预算线',[-2.05,3.25,-1.9,2.75],p=>{
      const poly=circle([0,0],rho15).map(image15);
      p.area(poly,C.blue,.15);p.path(poly,C.blue,{close:true});
      if(norm(x)) {
        boundary(p,x,b15,C.gold,'6 4');p.arrow(a015,plus(a015,times(x,.64)),C.blue,2.7);
        const worst=image15(times(unit(w),rho15));p.dot(worst,C.gold,5,true);p.text(worst,'a(u★)',C.gold,10,-11);
      }
      p.dot(a015,C.gray,4.5);p.text(a015,'a₀',C.gray,8,18);
      p.arrow(a015,a,C.red,2.7);p.dot(a,C.red);p.text(a,'a(u)',C.red,9,-10);
    },{...xy,x:'a₁',y:'a₂'}),{value:reading('a(u)^\\top x='+fmt(dot(a,x)),'b='+fmt(b15),'\\max a(u)^\\top x='+fmt(dot(a015,x)+rho15*norm(w)))});
  },{drag:(_,key,p)=>key==='u'?{theta:(Math.atan2(p[1],p[0])+2*pi)%(2*pi),r:Math.min(rho15,norm(p))}:null}),

  '15-2':model({focus:'all'},[
    choice('focus','接触点高亮',[['all','全部'],['1','p = 1'],['2','p = 2'],['inf','p = ∞']])
  ],s=>{
    const specs=[
      ['1','12/11',12/11,l1,[12/11,24/11],C.teal,'(12/11,24/11)'],
      ['2','1',1,circle([0,0],1),[8/5,9/5],C.blue,'(8/5,9/5)'],
      ['inf','6/7',6/7,linf,[12/7,12/7],C.violet,'(12/7,12/7)']
    ];
    return specs.map(([key,rf,r,ball,contact,c,exact])=>{
      const title=M(key==='inf'?'p=\\infty':'p='+key),active=s.focus==='all'||s.focus===key;
      return panel(title,chart('三角形内接范数球',[-.42,4.43,-.42,3.43],p=>{
        p.area([[0,0],[4,0],[0,3]],C.gray,.07);p.path([[0,0],[4,0],[0,3]],C.gray,{close:true,width:2.3});
        p.line([0,0],[2.1,2.1],C.gray,1.2,'5 4');
        const pp=ball.map(q=>plus([r,r],times(q,r)));
        p.area(pp,c,active?.23:.1);p.path(pp,c,{close:true,width:2.55});
        p.dot([r,r],c,4.6);p.text([r,r],'c★',c,-25,18);
        p.dot([0,r],c,4,true);p.dot([r,0],c,4,true);
        p.dot(contact,active?C.red:c,active?6:4.5);
        if(active)p.line([r,r],contact,c,1.7,'4 4');
      },xy),{value:reading('r^\\star='+rf,'c^\\star=('+rf+','+rf+')','x_{\\mathrm{contact}}='+exact)});
    }).join('');
  }),

  '16-1':model({trace:2,angle:-23,plane:'trace'},[
    range('trace','固定迹 u + v',.4,3.6,.02),range('angle','观察方向',-120,115,1),
    choice('plane','三维切面',[['trace','u + v 固定'],['zero','w = 0'],['off','仅锥面']]),
    preset('u + v = 2',{trace:2,plane:'trace'}),preset('恢复视角',{angle:-23})
  ],s=>{
    const r=s.trace/2;
    const cone=(t,h)=>[h*(1+Math.cos(t)),h*(1-Math.cos(t)),h*Math.sin(t)];
    const contour=seq(0,2*pi,140).map(t=>cone(t,r));
    const traceFace=seq(0,2*pi,56).map(t=>cone(t,r));
    const cells=mesh(cone,[0,2*pi],[0,2],40,12,C.blue,.20);
    if(s.plane==='trace') cells.push({vertices:traceFace,color:C.teal,opacity:.42});
    if(s.plane==='zero') cells.push({vertices:[[0,0,0],[4,0,0],[0,4,0]],color:C.teal,opacity:.36});
    const view=spatial('原坐标中的二阶半正定椭圆锥',[[0,4],[0,4],[-2.25,2.25]],{
      angle:s.angle,tilt:28,axes:['u','v','w'],cells,segments:s.plane==='off'?[]:s.plane==='trace'?
        [{vertices:contour,color:C.teal,width:3}]:[{vertices:[[4,0,0],[0,0,0],[0,4,0]],color:C.teal,width:3}],
      points:[{at:[1,1,2],name:'(1, 1, 2)',color:C.red}]
    });
    const ellipse=seq(0,2*pi,144).map(t=>[Math.SQRT2*r*Math.cos(t),r*Math.sin(t)]);
    return panel('原坐标中的半正定锥',view,{wide:true,legends:legend(['锥面',C.blue],['切片',C.teal],['锥外点',C.red]),
      value:reading('u,v\\ge0,\\quad w^2\\le uv','uv-w^2\\big|_{(1,1,2)}=-3')})+
      panel('对角截面 w = 0',chart('对角矩阵的第一象限',[-.45,4.2,-.45,4.2],p=>{
        p.area([[0,0],[4.2,0],[4.2,4.2],[0,4.2]],C.teal,.16);
        p.line([0,0],[4.2,0],C.teal,2.7);p.line([0,0],[0,4.2],C.teal,2.7);
        p.line([s.trace,0],[0,s.trace],C.gold,2.5,'5 4');
      },{x:'u',y:'v',equal:true}))+
      panel('固定迹的等比例截面',chart('迹截面在正交单位坐标中的椭圆',[-2.75,2.75,-2.3,2.3],p=>{
        p.area(ellipse,C.teal,.18);p.path(ellipse,C.teal,{close:true,width:2.8});
        p.dot([Math.SQRT2*r,0],C.teal);p.dot([0,r],C.blue);
        if(Math.abs(s.trace-2)<.01)p.dot([0,2],C.red,5.5);
      },{x:'(u−v)/√2',y:'w',equal:true}),{value:reading('u+v='+fmt(s.trace),'\\text{半轴 }'+fmt(Math.SQRT2*r)+',\\ '+fmt(r))});
  }),

  '16-2':model({x:.8,t:1.28,mode:'affine'},[
    range('x','矩阵参数 x',-2,2,.01),range('t','上盖 t',0,3.4,.02),
    choice('mode','矩阵形状',[['affine','仿射矩阵 B(x)'],['rank','可退化矩阵']]),
    preset('低于阈值',s=>({t:Math.max(0,specNorm(matrix(s.x,s.mode)).sigma-.3)})),
    preset('恰好压紧',s=>({t:specNorm(matrix(s.x,s.mode)).sigma})),
    preset('高于阈值',s=>({t:specNorm(matrix(s.x,s.mode)).sigma+.4})),
    preset('B = 0',{mode:'rank',x:0,t:0})
  ],s=>{
    const B=matrix(s.x,s.mode),{sigma,u}=specNorm(B),out=mv(B,u),
      f=x=>specNorm(matrix(x,s.mode)).sigma, xs=s.mode==='rank'?0:.25;
    return panel('单位圆经 B(x) 映射',chart('单位圆与矩阵像',[-3,3,-3,3],p=>{
      p.ring([0,0],1,C.gray,{dash:'5 4'});
      const ellipse=circle([0,0],1).map(u=>mv(B,u));
      p.area(ellipse,C.blue,.17);p.path(ellipse,C.blue,{close:true,width:2.7});
      if(sigma>1e-10) {p.arrow([0,0],out,C.red,3);p.dot(out,C.red,5.4);}
      else p.dot([0,0],C.blue,6);
    },{...xy,x:'输出分量 1',y:'输出分量 2'}),{value:reading('\\sigma_{\\max}(B(x))='+fmt(sigma))})+
      panel('谱范数上图',chart('半正定上盖的可行区域',[-2,2,0,3.45],p=>{
        above(p,f,-2,2,3.45,C.blue);p.curve(f,-2,2,C.blue);
        p.dot([xs,f(xs)],C.teal,5.1,true);
        p.line([s.x,0],[s.x,3.45],C.gray,1.5,'5 4');
        p.dot([s.x,s.t],s.t>=sigma-1e-9?C.teal:C.red,6);
      },{x:'x',y:'t'}),{value:reading('x='+fmt(s.x),'t='+fmt(s.t),'t-\\sigma_{\\max}='+fmt(s.t-sigma))+
        '<span>'+(s.t>=sigma-1e-9?'半正定':'非半正定')+'</span>'});
  }),

  '17-1':model({d:Math.log(2)},[
    range('d','对数差 u − v',-2,2,.01),preset('最优点',{d:Math.log(2)})
  ],s=>{
    const k=Math.log(9),u=(k+s.d)/2,v=(k-s.d)/2,x=Math.exp(u),y=Math.exp(v);
    const optimum=[3*Math.SQRT2,3/Math.SQRT2],F=d=>2*Math.exp(d)+8*Math.exp(-d);
    const ratios=[8,9.5,12.5,18].flatMap(t=>{
      const a=(t+Math.sqrt(t*t-64))/4,b=(t-Math.sqrt(t*t-64))/4;
      return a===b?[a]:[a,b];
    });
    return panel('原坐标：双曲线与射线',chart('双曲线、最优点及目标等高线',[0,8.6,0,8.6],p=>{
      ratios.forEach(r=>p.line([0,0],[8.6,8.6/r],Math.abs(r-2)<1e-8?C.teal:C.gray,1.7,'5 4'));
      p.curve(x=>9/x,9/8.6,8.6,C.blue,{width:3});
      p.dot(optimum,C.teal,6,true);p.dot([x,y],C.red,5.5,false,'xy');
      p.text(optimum,'最优点',C.teal,10,21);
    },{x:'x',y:'y',equal:true}),{key:'xy',value:reading('(x,y)='+vec([x,y]),'xy=9','f_0='+fmt(F(s.d)))})+
      panel('对数坐标：约束线与平谷',chart('对数变换后的平行等高线',[-.18,2.43,-.18,2.43],p=>{
        ratios.forEach(r=>boundary(p,[1,-1],Math.log(r),Math.abs(r-2)<1e-8?C.teal:C.gray,'5 4'));
        boundary(p,[1,1],k,C.blue);p.dot(optimum.map(Math.log),C.teal,6,true);
        p.dot([u,v],C.red,5.5,false,'uv');
      },{x:'u',y:'v',equal:true}),{key:'uv',value:reading('(u,v)='+vec([u,v]),'u+v=\\log 9','f_0^\\star=8')});
  },{drag:(_,key,p)=>key==='uv'?{d:clamp(p[0]-p[1],-2,2)}:
    key==='xy'&&p[0]>0?{d:clamp(2*Math.log(p[0]/3),-2,2)}:null}),

  '17-2':model({u:.15,v:.4,angle:43},[
    range('u','样本 u₁',-.55,.75,.02),range('v','样本 u₂',-.55,.75,.02),range('angle','观察方向',-95,125,1),
    preset('恢复视角',{angle:43})
  ],s=>{
    const a=Math.exp(-.55),b=Math.exp(.75),x=Math.exp(s.u),y=Math.exp(s.v);
    const left=spatial('正象限的乘积曲面',[[0,b],[0,b],[0,b*b]],{
      angle:s.angle,axes:['x₁','x₂','f'],cells:mesh((x,y)=>[x,y,x*y],[a,b],[a,b],24,22,C.blue,.23),
      segments:[{vertices:seq(a,b,100).map(x=>[x,y,x*y]),color:C.teal,width:2.65}],points:[{at:[x,y,x*y],name:'样本'}]
    });
    const right=spatial('对数坐标下的平面',[[-.55,.75],[-.55,.75],[-1.1,1.5]],{
      angle:s.angle,axes:['u₁','u₂','log f'],cells:mesh((u,v)=>[u,v,u+v],[-.55,.75],[-.55,.75],16,16,C.violet,.25),
      segments:[{vertices:[[-.55,s.v,-.55+s.v],[.75,s.v,.75+s.v]],color:C.teal,width:2.65}],points:[{at:[s.u,s.v,s.u+s.v],name:'同一样本'}]
    });
    return panel('Log-Sum-Exp 与最大值',chart('光滑上包络和最大值',[-3.35,3.35,-2.1,3.55],p=>{
      p.curve(u=>u,-3.35,3.35,C.gray,{dash:'5 4'});p.curve(u=>-u,-3.35,3.35,C.gray,{dash:'5 4'});
      p.curve(Math.abs,-3.35,3.35,C.teal);p.curve(lse,-3.35,3.35,C.blue,{width:3});
      p.line([0,0],[0,Math.log(2)],C.red,2.75);p.dot([0,Math.log(2)],C.red,5);
      p.text([0,Math.log(2)],'log 2',C.red);
      p.line([s.u,Math.abs(s.u)],[s.u,lse(s.u)],C.gold,2.8);p.dot([s.u,lse(s.u)],C.gold);
    },{x:'u',y:'高度'}),{wide:true,legends:legend([M('|u|'),C.teal],[M('\\log(e^u+e^{-u})'),C.blue],[M('\\pm u'),C.gray,true]),
      value:reading('\\ell(u)-|u|='+fmt(lse(s.u)-Math.abs(s.u)))})+
      panel('正象限乘积曲面',left,{value:reading('(x_1,x_2,f)='+vec([x,y,x*y]))})+
      panel('对数坐标平面',right,{value:reading('(u_1,u_2,\\log f)='+vec([s.u,s.v,s.u+s.v]))});
  }),

  '18-1':model({log:0,state:'finite',w:1},[
    range('log','log₁₀ ρ',-3,3,.025),range('w','离散反例的正权重',.12,3,.02),
    choice('state','岭路径位置',[['finite','有限正 ρ'],['left','ρ → 0⁺'],['right','ρ → ∞']]),
    preset('左上端',{state:'left'}),preset('有限权重',{state:'finite',log:0}),preset('右下端',{state:'right'})
  ],s=>{
    const rho=s.state==='finite'?10**s.log:s.state==='left'?0:Infinity;
    const at=ridgePoint(rho),low=Math.max(0,leftRidge[0]-.23),right=rightRidge[0]*1.13,top=leftRidge[1]*1.38;
    const points=[[0,3],[2,2],[3,0]],scores=points.map(p=>p[0]+s.w*p[1]),best=Math.min(...scores);
    return panel('岭回归的 Pareto 前沿',chart('真实岭解的拟合误差与参数能量',[low,right,0,top],p=>{
      p.area([[leftRidge[0],top],...pareto,[right,0],[right,top]],C.blue,.14);p.path(pareto,C.blue,{width:3});
      if(rho===0)p.line([at[0],0],[at[0],top],C.gold,2,'6 4');
      else if(rho===Infinity)p.line([low,0],[right,0],C.gold,2,'6 4');
      else boundary(p,[1,rho],at[0]+rho*at[1],C.gold,'6 4');
      p.dot(leftRidge,C.teal,5.5,true);p.dot(rightRidge,C.teal,5.5,true);
      p.text(leftRidge,'ρ → 0⁺',C.teal,12,-10);p.text(rightRidge,'ρ → ∞',C.teal,-53,-13);
      p.dot(at,C.red,6);
    },{x:'E',y:'R'}),{value:reading('\\rho='+(rho===Infinity?'+\\infty':fmt(rho,5)),'(E,R)='+vec(at,5))})+
      panel('离散三点与支撑线',chart('加权和看不到的 Pareto 点',[-.25,3.55,-.22,3.55],p=>{
        boundary(p,[1,s.w],best,C.gold,'6 4');
        points.forEach((q,i)=>{
          const supported=Math.abs(scores[i]-best)<1e-8,c=i===1?C.red:supported?C.teal:C.gray;
          p.dot(q,c,supported?6.4:5.5,!supported);
          p.text(q,['P₁','P₂','P₃'][i],c,9,-9);
        });
      },{x:'E',y:'R',equal:true}),{value:reading('E+'+fmt(s.w)+'R='+fmt(best))+'<span>'+
        points.map((_,i)=>Math.abs(scores[i]-best)<1e-8?'P'+(i+1):'').filter(Boolean).join('、')+' 取到最小值</span>'});
  }),

  '18-2':model({C:.85},[range('C','软间隔权重 C',.14,5,.01),preset('小权重',{C:.18}),preset('较大权重',{C:3.5})],s=>{
    const p=[1.65,.7],n=[-1.55,-.68],hard=hardPair(p,n),soft=softMargin(s.C);
    const height=2.35, box=[-3.15,3.15,-height,height];
    const guides=(g,w,b)=>{
      if(norm(w)<1e-10) return;
      boundary(g,w,1-b,C.blue,'5 4');boundary(g,w,-b,C.ink);
      boundary(g,w,-1-b,C.violet,'5 4');
    };
    const normw=norm(soft.w);
    return panel('两点硬间隔',chart('垂直平分线和两条平行护栏',box,g=>{
      guides(g,hard.w,hard.b);
      g.line(n,p,C.teal,2.4,'5 4');
      g.dot(p,C.blue,6);g.text(p,'u₊',C.blue);g.dot(n,C.violet,6);g.text(n,'u₋',C.violet,-29,-11);
      const mid=mix(p,n,.5);
      g.dot(mid,C.ink,4,true);g.right(mid,p,plus(mid,perp(hard.w)));
    },xy),{value:reading('\\gamma^\\star=\\|u_+-u_-\\|_2/2='+fmt(norm(minus(p,n))/2))})+
      panel('多点软间隔',chart('分类间隔、样本和最小松弛量',box,g=>{
        guides(g,soft.w,soft.b);
        for(const sign of [1,-1]) for(let i=0;i<positive.length;i++) {
          const q=times(positive[i],sign),c=sign===1?C.blue:C.violet,xi=soft.slack[i];
          if(xi>1e-7&&normw>1e-10) {
            const endpoint=plus(q,times(soft.w,sign*xi/(normw*normw)));
            g.arrow(q,endpoint,C.red,2.2);
          }
          g.dot(q,c,6,sign===-1);g.text(q,(sign===1?'+':'−')+(i+1),c,sign===1?9:-26,sign===1?-10:18);
        }
      },xy),{legends:legend(['正类',C.blue],['负类',C.violet],['最小松弛对应距离',C.red]),
        value:reading('C='+fmt(s.C),'\\|w\\|_2='+fmt(normw),'(\\xi_1,\\ldots,\\xi_4)='+vec(soft.slack),...(normw>1e-10?['(\\xi_i/\\|w\\|_2)_{i=1}^4='+vec(soft.slack.map(xi=>xi/normw))]:[]))});
  }),
};

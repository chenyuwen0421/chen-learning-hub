import {C, above, boundary, chart, choice, circle, dot, fmt, halfPlane, labelMath as M, legend,
  norm, panel, model, polar, preset, range, reading, seq, plus, times, vec} from './plot.mjs';
import * as P1 from './p1.mjs';

export const certificates = {
  '12-1':model({x:.55,lambda:.45},[
    range('x','可行点 x̃',-.3,1,.01),range('lambda','乘子 λ',0,2.5,.01),
    preset('闭合于 1.5',{x:1,lambda:1}),preset('保留间隙',{x:.55,lambda:.45})
  ],s=>{
    const f=x=>(x-2)**2/2+1,L=x=>f(x)+s.lambda*(x-1),g=lambda=>1+lambda-lambda*lambda/2;
    const lo=g(s.lambda),hi=f(s.x),xm=2-s.lambda;
    const bounds=[-.45,3.5,.25,4.4],b2=[0,2.5,.25,4.4];
    const guides=(p,left,right)=>{
      p.line([left,hi],[right,hi],C.blue,1.6,'5 4');
      p.line([left,lo],[right,lo],C.teal,1.6,'5 4');
    };
    return panel('原变量空间',chart('原可行点与拉格朗日函数',bounds,p=>{
      p.area([[-.45,.25],[1,.25],[1,4.4],[-.45,4.4]],C.blue,.08);
      p.line([1,.25],[1,4.4],C.gray,1.4,'5 4');guides(p,-.45,3.5);
      p.curve(f,-.45,3.5,C.blue);p.curve(L,-.45,3.5,C.violet,{dash:'6 4'});
      p.dot([s.x,hi],C.blue,6);p.text([s.x,hi],'上界',C.blue,9,-10);
      p.dot([xm,lo],C.teal,6);p.text([xm,lo],'L 的谷底',C.teal,10,19);
    },{x:'x',y:'高度'}),{legends:legend(['原目标',C.blue],['拉格朗日函数',C.violet,true])})+
    panel('乘子空间',chart('对偶凹曲线与上下界',b2,p=>{
      p.area([[0,lo],[2.5,lo],[2.5,hi],[0,hi]],C.gold,.11);guides(p,0,2.5);
      p.curve(g,0,2.5,C.teal);
      p.dot([1,1.5],C.red,5,true);p.dot([s.lambda,lo],C.teal,6);
    },{x:'λ',y:'高度'}),{value:reading('g(\\lambda)='+fmt(lo),'f_0(\\tilde x)='+fmt(hi),'f_0(\\tilde x)-g(\\lambda)='+fmt(hi-lo))});
  }),

  '13-1':model({state:'limit',lambda:1.3},[
    choice('state','右图支撑',[['limit','竖直极限'],['finite','有限斜率']]),
    range('lambda','有限支撑的 λ',.38,5,.02)
  ],s=>{
    const f=u=>Math.max(.5-u,0)**2,g=u=>-Math.sqrt(u);
    const l=chart('有严格可行点的可达集',[-.8,2,-1.3,2.1],p=>{
      above(p,f,-.8,2,2.1,C.blue);p.curve(f,-.8,2,C.blue);
      p.line([-.8,1.05],[2,-1.75],C.teal,2.3,'5 3');
      p.dot([-.5,1],C.red,6);p.text([-.5,1],'(−0.5, 1)',C.red,9,-10);
      p.dot([0,.25],C.teal,5);p.text([0,.25],'(0, 0.25)',C.teal);
    },{x:'u',y:'t'});
    const r=chart('可达集在 u=0 的竖直支撑',[-.8,2,-1.3,2.1],p=>{
      above(p,g,0,2,2.1,C.blue);p.curve(g,0,2,C.blue);
      p.line([0,0],[0,2.1],C.blue,2.8);
      if(s.state==='limit')p.line([0,-1.3],[0,2.1],C.teal,2.2,'6 4');
      else {
        const t=u=>-s.lambda*u-1/(4*s.lambda),u=1/(4*s.lambda*s.lambda);
        p.curve(t,-.8,2,C.teal,{dash:'5 4'});p.dot([u,g(u)],C.teal,5.2);
      }
      p.dot([0,0],C.red,5);p.text([0,0],'(0, 0)',C.red,10,-10);
    },{x:'u',y:'t'});
    return panel('有严格可行点',l,{value:reading('p^\\star=1/4','\\lambda^\\star=1')})+
      panel('无严格可行点',r,{value:reading(s.state==='limit'?'u=0':'g(\\lambda)='+fmt(-1/(4*s.lambda)))});
  }),

  '13-2':model({b:1},[
    range('b','预算 b',-1,4,.02),preset('不活跃',{b:3.1}),preset('临界',{b:2}),preset('活跃',{b:1})
  ],s=>{
    const {x,lambda,value}=P1.budget(s.b),v=b=>P1.budget(b).value,
      gradient=P1.gradient(x),normal=times(P1.a,lambda);
    const status=s.b>2?'不活跃':s.b===2?'临界 · 零乘子':'活跃';
    return panel('预算边界 · '+status,chart('预算平移与最优点的路径',[-1.7,3.6,-3.05,2.8],p=>{
      halfPlane(p,P1.a,s.b,C.teal);P1.ellipses(p,[.25,.6,1.2,2.5,5,8]);
      p.line(P1.budget(-1).x,P1.z,C.gold,2.15,'5 4');p.dot(P1.z,C.gray,5,true);p.text(P1.z,'z',C.gray,9,17);
      if(lambda>0){
        p.arrow(x,plus(x,times(gradient,.27)),C.red,3);
        p.arrow(x,plus(x,times(normal,.27)),C.blue,3);
      }
      p.dot(x,C.gold,6);p.text(x,'x★',C.gold,-26,15);
    },{x:'x₁',y:'x₂',equal:true}),{legends:legend(['梯度方向',C.red],['乘子法向',C.blue],['解路径',C.gold,true]),
      value:reading('b='+fmt(s.b),'x^\\star='+vec(x),'\\lambda^\\star='+fmt(lambda))})+
    panel('最优值与预算',chart('预算的最优值函数与切线',[-1,4,0,10.5],p=>{
      p.curve(v,-1,4,C.blue);p.line([2,0],[2,v(2)],C.gray,1.7,'5 4');
      p.dot([2,v(2)],C.teal,5,true);p.text([2,v(2)],'b = 2',C.teal,10,18);
      p.line([s.b-.57,value+.57*lambda],[s.b+.57,value-.57*lambda],C.red,2.35);
      p.dot([s.b,value],C.gold,6);
    },{x:'b',y:'p★(b)'}),{value:reading('p^\\star(b)='+fmt(value),'p^{\\star\\prime}(b)=-\\lambda^\\star='+fmt(-lambda))});
  }),

  '14-1':model({y:1,c:0},[
    range('y','斜率 y',-2,2,.02),range('c','竖直参数 c',-2,3,.02),
    preset('支撑线',s=>({c:s.y*s.y/2-.5})),preset('穿透曲线',s=>({c:s.y*s.y/2-1})),
    preset('过低直线',s=>({c:s.y*s.y/2+.15})),preset('y = 0',{y:0,c:-.5})
  ],s=>{
    const f=x=>x*x/2+.5,g=y=>y*y/2-.5,cstar=g(s.y),l=x=>s.y*x-s.c;
    const status=Math.abs(s.c-cstar)<1e-8?'支撑':s.c<cstar?'穿透':'过低';
    return panel('固定斜率与竖直平移',chart('原曲线、斜率线和支撑线',[-2.55,2.55,-3,4],p=>{
      if(s.c<cstar) {
        const d=Math.sqrt(2*(cstar-s.c)),lo=Math.max(-2.55,s.y-d),hi=Math.min(2.55,s.y+d);
        p.area([...seq(lo,hi,80).map(x=>[x,l(x)]),...seq(hi,lo,80).map(x=>[x,f(x)])],C.red,.2);
      }
      p.curve(f,-2.55,2.55,C.blue);p.curve(x=>s.y*x,-2.55,2.55,C.gray,{dash:'4 4',width:1.5});
      p.curve(x=>s.y*x-cstar,-2.55,2.55,C.teal,{dash:'5 4',width:2});
      p.curve(l,-2.55,2.55,C.gold,{width:2.6});
      p.arrow([s.y,s.y*s.y],[s.y,f(s.y)],C.violet,2.4);
      p.dot([s.y,f(s.y)],C.teal,5.5);
      p.dot([0,-s.c],C.gold,4.8,true);
    },{x:'x',y:'高度'}),{legends:legend([M('f(x)'),C.blue],[M('yx-c'),C.gold],['支撑线',C.teal,true]),
      value:reading('-c='+fmt(-s.c),'-f^\\ast(y)='+fmt(-cstar))+'<span>'+status+'</span>'})+
    panel('斜率空间的共轭',chart('共轭函数与当前斜率',[-2,2,-.75,2],p=>{
      p.curve(g,-2,2,C.violet);p.dot([s.y,cstar],C.violet,6);
      p.line([s.y,-.75],[s.y,cstar],C.gray,1.4,'5 4');
    },{x:'y',y:'f*(y)'}),{value:reading('f^\\ast(y)='+fmt(cstar),'x^\\star=y='+fmt(s.y))});
  }),

  '14-2':model({q:1,x:.45},[
    range('q','原函数曲率 q',.25,4,.05),range('x','接触点 x',-.48,.48,.01),
    preset('小曲率',{q:.25}),preset('单位曲率',{q:1}),preset('大曲率',{q:4})
  ],s=>{
    const y=s.q*s.x, f=x=>s.q*x*x/2,g=y=>y*y/(2*s.q);
    function draw(F,u,isDual) {
      const ax=isDual?'y':'x',c=isDual?C.violet:C.blue;
      return panel(M(isDual?'f^\\ast(y)=y^2/(2q)':'f(x)=qx^2/2'),
        chart('固定高度尺上的倒数曲率',[-2,2,0,8.25],p=>{
          p.curve(F,-2,2,c);p.dot([u,F(u)],C.gold,6);
          p.line([u,0],[u,F(u)],C.gray,1.4,'4 4');
        },{x:ax,y:'高度'}),{value:reading(ax+'='+fmt(u),isDual?'1/q='+fmt(1/s.q):'q='+fmt(s.q))});
    }
    return draw(f,s.x,false)+draw(g,y,true);
  }),

  '14-3':model({y:.75},[
    range('y','斜率 y',-2,2,.02),preset('区间内部',{y:.6}),preset('y = −1',{y:-1}),preset('y = 1',{y:1}),
    preset('正半轴发散',{y:1.45}),preset('负半轴发散',{y:-1.45})
  ],s=>{
    const inside=Math.abs(s.y)<=1;
    return panel('绝对值与过原点的斜率线',chart('斜率线与绝对值曲线',[-2.3,2.3,-2.5,4.5],p=>{
      p.curve(Math.abs,-2.3,2.3,C.blue);p.curve(x=>s.y*x,-2.3,2.3,C.gold,{dash:'6 4'});
      p.dot([0,0],C.teal,5);
      if(!inside) {
        const side=Math.sign(s.y);
        p.area([[0,0],[side*2.3,2.3],[side*2.3,Math.abs(s.y)*2.3]],C.red,.20);
        p.arrow([side*1.45,Math.abs(s.y)*1.45],[side*2.15,Math.abs(s.y)*2.15],C.red,2.9);
      }
    },{x:'x',y:'高度'}),{legends:legend([M('|x|'),C.blue],[M('yx'),C.gold,true])})+
    panel('扩展值共轭',chart('区间内零值与区间外正无穷',[-2.2,2.2,-.4,2.35],p=>{
      p.line([-1,0],[1,0],C.teal,4);p.dot([-1,0],C.teal,5);p.dot([1,0],C.teal,5);
      for(const a of [-1.85,-1.46,1.46,1.85])p.arrow([a,.57],[a,1.68],C.gray,1.5,'4 3');
      p.text([-1.65,1.8],'+∞',C.gray,-10,0);p.text([1.65,1.8],'+∞',C.gray,-10,0);
      if(inside)p.dot([s.y,0],C.red,6);else p.arrow([s.y,.23],[s.y,1.56],C.red,3);
    },{x:'y',y:'f*(y)',yt:[0]}),{value:reading('y='+fmt(s.y),'f^\\ast(y)='+(inside?'0':'+\\infty'))});
  }),

  '14-4':model({theta:34,r:1.15},[
    range('theta','向量 y 的方向',0,360,1),range('r','向量长度',0,1.25,.01),
    preset('一般方向',{theta:34,r:1.15}),preset('坐标轴',{theta:0,r:1.15}),
    preset('对角方向',{theta:45,r:1.15}),preset('零向量',{r:0})
  ],s=>{
    const y=polar(s.theta*Math.PI/180,s.r),v2=circle([0,0],1),v1=[[1,0],[0,1],[-1,0],[0,-1]],vi=[[1,1],[-1,1],[-1,-1],[1,-1]];
    const specs=[[M('\\ell_2'),v2,norm(y),s.r?[times(y,1/norm(y))]:[],C.blue],
      [M('\\ell_\\infty'),vi,Math.abs(y[0])+Math.abs(y[1]),vi,C.violet],
      [M('\\ell_1'),v1,Math.max(...y.map(Math.abs)),v1,C.teal]];
    return specs.map(([title,poly,h,candidates,c])=>{
      const contacts=candidates.filter(x=>Math.abs(dot(y,x)-h)<1e-8);
      return panel(title,chart('单位球与同向支撑线',[-1.6,1.6,-1.6,1.6],p=>{
        p.area(poly,c,s.r?.15:.26);p.path(poly,c,{close:true,width:2.4});
        if(s.r){
          boundary(p,y,h,C.gold,'6 4');p.arrow([0,0],y,C.red,2.8);p.text(y,'y',C.red,7,-9);
          if(contacts.length>1)p.path(contacts,C.gold,{width:4});
          contacts.forEach(q=>p.dot(q,C.gold,5.4));
        }
      },{x:'x₁',y:'x₂',equal:true}),{value:reading('\\|y\\|_\\ast='+fmt(h))+
        (!s.r?'<span>整个单位球</span>':contacts.length>1?'<span>最优边</span>':'')});
    }).join('');
  }),
};

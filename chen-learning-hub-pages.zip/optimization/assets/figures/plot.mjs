import {e as katex} from '../vendor/math-bundle.mjs';

export const C = {
  blue:'var(--graph-blue)', teal:'var(--graph-teal)', red:'var(--graph-red)',
  gold:'var(--graph-gold)', violet:'var(--graph-violet)', gray:'var(--graph-gray)',
  ink:'var(--ink)', grid:'var(--line)', paper:'var(--paper)', soft:'var(--soft)',
};
export const pi = Math.PI;
export const dot = (a,b) => a.reduce((sum,v,i)=>sum+v*b[i],0);
export const plus = (a,b) => a.map((v,i)=>v+b[i]);
export const minus = (a,b) => a.map((v,i)=>v-b[i]);
export const times = (a,t) => a.map(v=>v*t);
export const norm = a => Math.hypot(...a);
export const unit = a => norm(a)>1e-12 ? times(a,1/norm(a)) : a.map(()=>0);
export const perp = ([x,y]) => [-y,x];
export const mix = (a,b,t) => plus(times(a,1-t),times(b,t));
export const polar = (theta,r=1) => [r*Math.cos(theta),r*Math.sin(theta)];
export const clamp = (value,lo,hi) => Math.max(lo,Math.min(hi,value));
export const fmt = (v,n=3) => Math.abs(v)<0.5*10**(-n) ? '0' : Number(v.toFixed(n)).toString();
export const vec = (v,n=3) => '('+v.map(x=>fmt(x,n)).join(', ')+')';
export const seq = (a,b,n) => Array.from({length:n+1},(_,i)=>a+(b-a)*i/n);
export const circle = (p,r,n=96) => seq(0,2*pi,n).map(theta=>plus(p,polar(theta,r)));
export const curve = (f,lo,hi,n=144) => seq(lo,hi,n).map(x=>[x,f(x)]);
export const escape = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export const math = tex => katex.renderToString(tex,{strict:'ignore',throwOnError:true});
export const labelMath = tex => ({tex});
export const legend = (...items) => items.map(([label,color,dash]) =>
  '<span><i style="--sample:'+color+'"'+(dash?' class="dashed"':'')+'></i>'+readLabel(label)+'</span>').join('');
const readLabel = label => typeof label==='object' ? math(label.tex) : escape(label);
let svgId = 0;

export function line(a,b,stroke=C.blue,width=2.4,dash='',extra='') {
  return '<line x1="'+a[0]+'" y1="'+a[1]+'" x2="'+b[0]+'" y2="'+b[1]+'" stroke="'+stroke+'" stroke-width="'+width+'" '+(dash?'stroke-dasharray="'+dash+'" ':'')+extra+'/>';
}
export function path(points,stroke=C.blue,options={}) {
  const {fill='none',width=2.5,dash='',close=false,opacity=1} = options;
  const d = points.reduce((p,v,i)=>!v?.every(Number.isFinite) ? p
    : p+((i && points[i-1]?.every(Number.isFinite))?'L':'M')+v.map(x=>fmt(x,3)).join(' '),'');
  return '<path d="'+d+(close?'Z':'')+'" fill="'+fill+'" stroke="'+stroke+'" opacity="'+opacity+'" stroke-width="'+width+'" '+(dash?'stroke-dasharray="'+dash+'"':'')+'/>';
}
export function text(p,label,color=C.ink,{anchor='start',size=16,weight=600,outline=true}={}) {
  return '<text x="'+p[0]+'" y="'+p[1]+'" fill="'+color+'" text-anchor="'+anchor+'" font-size="'+size+'" font-weight="'+weight+'"'+(outline?' class="plot-label"':'')+'>'+escape(label)+'</text>';
}
export function point(p,fill=C.blue,r=5,open=false,draggable='') {
  return '<circle cx="'+p[0]+'" cy="'+p[1]+'" r="'+r+'" fill="'+(open?C.paper:fill)+'" stroke="'+(open?fill:C.paper)+'" stroke-width="'+(open?2.2:1.5)+'"'+(draggable?' data-drag="'+escape(draggable)+'" class="drag-point"':'')+'/>';
}
export function arrow(a,b,color=C.blue,width=2.5,dash='') {
  const distance = norm(minus(b,a));
  if (distance<2) return '';
  const forward = unit(minus(b,a)), length = Math.min(distance*.65,9);
  const base = minus(b,times(forward,length));
  const wing = times(perp(forward),length*.48);
  return line(a,base,color,width,dash)+path([b,plus(base,wing),minus(base,wing)],'none',{fill:color,close:true});
}
export function svg(title,width,height,body,attributes='') {
  return '<svg class="math-plot" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+width+' '+height+'" role="img" aria-label="'+escape(title)+'" '+attributes+'><title>'+escape(title)+'</title>'+body+'</svg>';
}

function niceTicks(lo,hi,target=5) {
  const raw = (hi-lo)/target;
  const mag = 10**Math.floor(Math.log10(raw));
  const step = [1,2,2.5,5,10].find(x=>x*mag>=raw)*mag;
  const first = Math.ceil((lo-1e-10)/step)*step;
  return seq(0,Math.max(0,Math.floor((hi-first+1e-10)/step)),Math.max(1,Math.floor((hi-first+1e-10)/step)))
    .map(i=>first+i*step).filter((v,i,a)=>v<=hi+1e-10 && (i===0 || v!==a[i-1]));
}

export function chart(title, bounds, draw, options={}) {
  const [xmin,xmax,ymin,ymax] = bounds;
  const {x='x',y='y',equal=false,width=440,height=325,xt,yt,xTick=fmt,yTick=fmt} = options;
  const p0 = [53,26], p1 = [width-24,height-45];
  let sx = (p1[0]-p0[0])/(xmax-xmin), sy = (p1[1]-p0[1])/(ymax-ymin);
  if (equal) {
    const s = Math.min(sx,sy);
    p0[0] += ((p1[0]-p0[0])-(xmax-xmin)*s)/2;
    p0[1] += ((p1[1]-p0[1])-(ymax-ymin)*s)/2;
    sx = sy = s;
    p1[0] = p0[0]+(xmax-xmin)*s;
    p1[1] = p0[1]+(ymax-ymin)*s;
  }
  const P = ([a,b])=>[p0[0]+(a-xmin)*sx,p1[1]-(b-ymin)*sy];
  const id = 'plot-'+(++svgId);
  const ink = [];
  const marks = [];
  const pen = {
    P, bounds,
    line:(a,b,c,w,d)=>ink.push(line(P(a),P(b),c,w,d)),
    arrow:(a,b,c,w,d)=>ink.push(arrow(P(a),P(b),c,w,d)),
    path:(points,c,o)=>ink.push(path(points.map(p=>p?P(p):null),c,o)),
    curve:(f,a,b,c,o)=>ink.push(path(curve(f,a,b).map(P),c,o)),
    area:(points,c,opacity=.15)=>ink.push(path(points.map(P),'none',{fill:c,opacity,close:true})),
    dot:(p,c=C.blue,r=5,open=false,drag='')=>ink.push(point(P(p),c,r,open,drag)),
    text:(p,s,c,dx=9,dy=-8,style)=>marks.push(text(plus(P(p),[dx,dy]),s,c,style)),
    right:(p,a,b,c=C.gray)=> {
      const u=unit(minus(a,p)),v=unit(minus(b,p));
      if(norm(u)&&norm(v)&&Math.abs(dot(u,v))<1e-7) {
        const s=12/Math.min(sx,sy);
        ink.push(path([plus(p,times(u,s)),plus(p,times(plus(u,v),s)),plus(p,times(v,s))].map(P),c,{width:1.5}));
      }
    },
    ring:(p,r,c=C.blue,o={})=>ink.push(path(circle(p,r).map(P),c,{...o,close:true})),
  };
  draw(pen);
  const xticks = xt ?? niceTicks(xmin,xmax), yticks = yt ?? niceTicks(ymin,ymax);
  const grids = xticks.map(t=>line(P([t,ymin]),P([t,ymax]),C.grid,1)).join('')+
    yticks.map(t=>line(P([xmin,t]),P([xmax,t]),C.grid,1)).join('');
  const zeroX = clamp(0,xmin,xmax), zeroY = clamp(0,ymin,ymax);
  const axes = arrow(P([xmin,zeroY]),P([xmax,zeroY]),C.gray,1.1)+arrow(P([zeroX,ymin]),P([zeroX,ymax]),C.gray,1.1);
  const ticks = xticks.map(t=>text([P([t,0])[0],p1[1]+19],xTick(t,3),C.gray,{anchor:'middle',size:14,weight:500,outline:false})).join('')+
    yticks.map(t=>text([p0[0]-8,P([0,t])[1]+4],yTick(t,3),C.gray,{anchor:'end',size:14,weight:500,outline:false})).join('');
  const box = '<rect x="'+p0[0]+'" y="'+p0[1]+'" width="'+(p1[0]-p0[0])+'" height="'+(p1[1]-p0[1])+'" rx="3"';
  return svg(title,width,height,'<defs><clipPath id="'+id+'">'+box+'/></clipPath></defs>'+
    box+' fill="'+C.paper+'" stroke="'+C.grid+'"/>'+grids+axes+
    '<g clip-path="url(#'+id+')">'+ink.join('')+'</g>'+marks.join('')+ticks+
    text([p1[0]+1,p1[1]+40],x,C.ink,{anchor:'end',size:16})+text([p0[0],18],y,C.ink,{size:16}),
    'data-coords="'+[p0[0],p1[1],sx,sy,xmin,ymin].join(',')+'"');
}

export function above(p,f,a,b,ymax,color=C.blue,alpha=.13) {
  p.area([[a,ymax],...curve(f,a,b),[b,ymax]],color,alpha);
}
export function below(p,f,a,b,ymin,color=C.blue,alpha=.13) {
  p.area([[a,ymin],...curve(f,a,b),[b,ymin]],color,alpha);
}
export function clip(poly,a,b,tol=1e-10) {
  const result = [];
  for (let i=0;i<poly.length;i++) {
    const from=poly[i],to=poly[(i+1)%poly.length],df=dot(a,from)-b,dt=dot(a,to)-b;
    if(df<=tol) result.push(from);
    if((df<=tol)!==(dt<=tol)) result.push(mix(from,to,clamp(df/(df-dt),0,1)));
  }
  return result;
}
export function boundary(p,a,b,c=C.blue,dash='') {
  const [x0,x1,y0,y1]=p.bounds;
  const mid=times(a,b/dot(a,a));
  const along=times(unit(perp(a)),2*Math.max(x1-x0,y1-y0,norm(mid)));
  p.line(minus(mid,along),plus(mid,along),c,2.2,dash);
}
export function halfPlane(p,a,b,color=C.blue) {
  const [x0,x1,y0,y1]=p.bounds;
  p.area(clip([[x0,y0],[x1,y0],[x1,y1],[x0,y1]],a,b),color,.12);
  boundary(p,a,b,color);
}
export function halfProjection(z,a,b) {
  const d=dot(a,z)-b, a2=dot(a,a);
  return a2>0 && d>0 ? minus(z,times(a,d/a2)) : z.slice();
}
export function levels(p,values,center,rx,ry,theta=0,color=C.gray) {
  for(const v of values) {
    p.path(seq(0,2*pi,120).map(t=>{
      const x=rx(v)*Math.cos(t),y=ry(v)*Math.sin(t);
      return plus(center,[x*Math.cos(theta)-y*Math.sin(theta),x*Math.sin(theta)+y*Math.cos(theta)]);
    }),color,{width:1.1,opacity:.60});
  }
}
export function panel(title,markup,{key='',legends='',value='',wide=false}={}) {
  return '<section class="plot-panel'+(wide?' plot-wide':'')+'" data-panel="'+escape(key)+'"><h4>'+readLabel(title)+'</h4>'+markup+
    (legends?'<div class="plot-legend">'+legends+'</div>':'')+(value?'<div class="plot-value">'+value+'</div>':'')+'</section>';
}
export function reading(...tex) {
  return tex.map(t=>'<span>'+math(t)+'</span>').join('');
}
export function bars(parts) {
  const total = parts.reduce((s,p)=>s+p[1],0);
  return '<div class="measure-bar" aria-hidden="true">'+parts.map(([name,value,color])=>
    '<i style="width:'+(total>0?100*value/total:0)+'%;background:'+color+'"></i>').join('')+'</div>'+
    '<div class="plot-legend">'+legend(...parts.map(([name,value,color])=>[name+' = '+fmt(value),color]))+'</div>';
}

export const range = (key,label,min,max,step=.01) => ({type:'range',key,label,min,max,step});
export const choice = (key,label,options) => ({type:'select',key,label,options});
export const preset = (label,values) => ({type:'button',label,change:typeof values==='function'?values:()=>values});
export const model = (initial,controls,render,{drag}={}) => ({initial,controls,render,drag});

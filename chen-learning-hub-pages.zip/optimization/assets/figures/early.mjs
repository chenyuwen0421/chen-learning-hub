import {
  C, above, arrow, boundary, bars, chart, circle, clamp, clip, curve, dot, fmt, halfPlane,
  halfProjection, labelMath as M, legend, levels, line, mix, model, norm, panel, path, pi,
  plus, point, polar, preset, range, reading, seq, svg, text, times, minus, unit, vec, choice
} from './plot.mjs';
import {mesh, spatial} from './space.mjs';
import {deadZone, fitHuber, fitPiecewise, huber, normalSystem, ridge, sampleX, sampleY, spectral, squaredError} from './regression.mjs';

const a0=[1,2], b0=4, z0=[3,3], p0=[2,1], box0=[-1,5,-1,5];
const xy={x:'x₁',y:'x₂',equal:true};

function mapDiagram(active) {
  const boxes=[
    {p:[17,25], title:'允许区域', sub:'哪些方案合法？'},
    {p:[241,25], title:'目标', sub:'谁的代价更低？'},
    {p:[241,207], title:'改善', sub:'朝哪个方向走一步？'},
    {p:[17,207], title:'证书', sub:'凭什么没人能比它更好？'},
  ];
  const links=[
    [[196,61],[239,61],[217,18],'放入标尺'],
    [[328,103],[328,205],[326,155],'读取局部坡度'],
    [[241,246],[197,246],[218,303],'何时停止？'],
    [[106,207],[106,104],[109,155],'在边界内移动'],
  ];
  const content=links.map(([a,b,at,label],i)=>arrow(a,b,i===active?C.blue:C.gray,1.9)+
    text(at,label,C.ink,{anchor:'middle',size:15})).join('')+
    boxes.map(({p,title,sub},i)=>'<rect x="'+p[0]+'" y="'+p[1]+'" width="178" height="77" rx="10" fill="'+(i===active?C.blue:C.soft)+'" fill-opacity="'+(i===active?.12:1)+'" stroke="'+(i===active?C.blue:C.grid)+'"/>'+
      text(plus(p,[15,31]),title,C.blue,{size:20,outline:false})+
      text(plus(p,[11,58]),sub,C.ink,{size:13.5,outline:false})).join('');
  return svg('允许区域、目标、改善与证书',440,319,content);
}
function openingFrame(stage,active) {
  const titles=['允许区域','局部改善','全局证书'];
  const c=stage===active?C.blue:C.gray;
  const figure=chart(titles[stage],[-1,5,-1,5],p=>{
    halfPlane(p,a0,b0,c);
    if(stage!==0) levels(p,[.8,2,4,5,7,10],z0,Math.sqrt,Math.sqrt,0,c);
    if(stage===1) {p.dot([-.1,.8],C.blue);p.arrow([-.1,.8],[.65,1.15],C.gold,3);p.text([-.1,.8],'x',C.blue,-15,-11);}
    if(stage===2) {
      p.ring(z0,Math.sqrt(5),C.gold,{width:2.4});p.dot(p0,C.red);p.text(p0,'x★',C.red,-24,18);
      p.arrow([1.55,1.9],[2.4,.2],C.blue,3);p.text([2.4,.2],'支撑线',C.blue,8,3);
    }
  },{...xy,height:285});
  return panel(titles[stage],figure);
}
export const early = {
  '00-1':model({stage:0},[
    preset('划定允许区域',{stage:0}),preset('局部改善',{stage:1}),preset('全局证书',{stage:2})
  ],s=>openingFrame(0,s.stage)+panel('允许区域—目标—改善—证书',mapDiagram([0,2,3][s.stage]))+
    openingFrame(1,s.stage)+openingFrame(2,s.stage)),

  '01-1':model({x:3,y:3,r:Math.sqrt(5)},[
    range('r','半径 R',0,5,.01),range('x','z₁',-1,5,.05),range('y','z₂',-1,5,.05),
    preset('未触及',s=>({r:Math.max(0,norm(minus([s.x,s.y],halfProjection([s.x,s.y],a0,b0)))-.7)})),
    preset('相切',s=>({r:norm(minus([s.x,s.y],halfProjection([s.x,s.y],a0,b0)))})),
    preset('交叉',s=>({r:Math.min(5,norm(minus([s.x,s.y],halfProjection([s.x,s.y],a0,b0)))+.75)}))
  ],s=>{
    const z=[s.x,s.y], proj=halfProjection(z,a0,b0), distance=norm(minus(z,proj));
    function draw(title,center,foot,r,drag=false) {
      return chart(title,box0,p=>{
        halfPlane(p,a0,b0,C.teal);
        p.ring(center,r,C.gold,{fill:C.gold,opacity:.18});
        p.ring(center,r,C.gold,{width:2.3});
        p.arrow(foot,plus(foot,times(a0,.45)),C.red,2.5);
        p.line(center,foot,C.blue,2.3,'5 4');
        p.right(foot,center,plus(foot,[2,-1]));
        p.dot(foot,C.blue,5);
        p.text(foot,'x★',C.blue,-25,17);
        p.dot(center,C.red,6,false,drag?'z':'');p.text(center,'z',C.red,10,-11);
        p.text([.6,.5],'aᵀx ≤ 4',C.teal);
      },xy);
    }
    const current=distance===0?'z 已在合法区域':s.r<distance-1e-6?'尚未触及':s.r>distance+1e-6?'圆与边界交叉':'相切';
    return panel('距离圆 · '+current,draw('半空间、参考点与投影',z,proj,distance===0?0:s.r,true),
      {key:'main',wide:true,value:reading('x^\\star='+vec(proj),'\\|z-x^\\star\\|_2='+fmt(distance),'R='+fmt(distance===0?0:s.r))})+
      [['未触及',1.5],['相切',Math.sqrt(5)],['交叉',3]].map(([title,r])=>panel(title,
        draw(title,z0,p0,r),{value:reading('R='+fmt(r))})).join('');
  },{drag:(_,key,p)=>key==='z'?{x:clamp(p[0],-1,5),y:clamp(p[1],-1,5)}:null}),

  '01-2':model({u:1.05,depth:0},[
    range('u','沿边界的位移',-2.3,2.3,.02),range('depth','向半空间内移动',0,1.7,.02),
    preset('边界上的点',{u:1.2,depth:0}),preset('严格内部的点',{u:1.2,depth:.8})
  ],s=>{
    const d=minus(p0,z0), tangent=unit([2,-1]), outward=unit(a0);
    function candidate(u,h){return plus(p0,minus(times(tangent,u),times(outward,h)));}
    function draw(title,u,h,draggable) {
      const x=candidate(u,h),w=minus(x,p0),parts=[['法向代价',dot(d,d)/2,C.blue],['偏离代价',dot(w,w)/2,C.teal],['交叉项',Math.max(0,dot(d,w)),C.gold]];
      return panel(title,chart(title,box0,p=>{
        halfPlane(p,a0,b0,C.teal);
        p.arrow(z0,p0,C.blue,3);
        p.arrow(p0,x,C.teal,3);
        p.arrow(z0,x,C.gold,2.4,'5 4');
        p.right(p0,z0,x);
        p.dot(z0,C.red);p.text(z0,'z',C.red);
        p.dot(p0,C.blue);p.text(p0,'x★',C.blue,-24,18);
        p.dot(x,C.teal,6,false,draggable?'x':'');p.text(x,'x',C.teal,8,16);
      },xy),{key:draggable?'main':'',value:bars(parts)+reading('\\tfrac12\\|x-z\\|_2^2='+fmt(parts.reduce((t,p)=>t+p[1],0)))});
    }
    return draw('当前位移分解',s.u,s.depth,true)+draw('严格内部的点',1.2,.8,false);
  },{drag:(_,key,p)=>key==='x'?{u:clamp(dot(minus(p,p0),unit([2,-1])),-2.3,2.3),depth:clamp(-dot(minus(p,p0),unit(a0)),0,1.7)}:null}),

  '01-3':model({x:3,closed:'open'},[
    range('x','向右探索',.5,100,.5),choice('closed','右图可行边界',[['open','x < 2'],['closed','x ≤ 2']]),
    preset('向右探索至 100',{x:100})
  ],s=>{
    const f=x=>1/x,g=x=>(x-3)**2/2,limit=Math.max(10,s.x*1.05);
    return panel(M('f(x)=1/x,\\quad x>0'),chart('双曲线与下确界',[0,limit,0,2.25],p=>{
      p.line([0,0],[limit,0],C.gold,2,'5 5');
      p.path(seq(.38**.5,Math.sqrt(limit),180).map(t=>[t*t,f(t*t)]),C.blue);
      p.dot([s.x,f(s.x)],C.red);p.text([s.x,f(s.x)],'f(x)',C.red,s.x>limit*.8?-36:9,-12);
    },{x:'x',y:'f(x)'}),{value:reading('x='+fmt(s.x),'f(x)='+fmt(f(s.x),5),'\\inf f=0')})+
    panel(M('f(x)=\\tfrac12(x-3)^2'),chart('开端点与闭端点',[0,4,0,4.5],p=>{
      p.curve(g,0,2,C.blue);p.curve(g,2,4,C.gray,{dash:'5 5',width:1.7});
      p.dot([2,.5],C.red,6,s.closed==='open');p.text([2,.5],'(2, 0.5)',C.red);
      p.line([2,0],[2,.5],C.red,1.4,'5 4');
    },{x:'x',y:'f(x)'}),{value:reading(s.closed==='open'?'x<2,\\ \\inf f=0.5':'x\\le2,\\ \\min f=0.5')});
  }),

  '02-1':model({l:-1.1,r:1.1,angle:26},[
    range('l','弦左端 x',-1.45,-.05,.01),range('r','弦右端 y',.05,1.45,.01),
    range('angle','圆环端点角度',5,90,1),
    preset('平底取等',{l:-.8,r:.8}),preset('双阱反例',{l:-1,r:1})
  ],s=>{
    const t=s.angle*pi/180, ring=[...seq(0,pi,100).map(u=>polar(u,2)),...seq(pi,0,100).map(u=>polar(u,1))];
    const A=polar(t,1.5),B=polar(pi-t,1.5);
    const ok = Math.min(A[1],B[1])>=1-1e-12;
    const half=ok?0:Math.sqrt(1-A[1]**2);
    const g1=chart('凸多边形',[-2.2,2.2,-.55,2.3],p=>{
      const polygon=[[-1.8,.3],[-.8,1.9],[.85,1.8],[1.7,.8],[.8,-.2]];
      p.area(polygon,C.blue,.18);p.path(polygon,C.blue,{close:true});
      const a=mix(polygon[0],polygon[1],s.angle/100),b=mix(polygon[2],polygon[3],s.angle/100);
      p.line(a,b,C.teal,3);p.dot(a,C.teal);p.dot(b,C.teal);
    },xy);
    const g2=chart('上半圆环',[-2.2,2.2,-.55,2.3],p=>{
      p.area(ring,C.blue,.16);p.path(ring,C.blue,{close:true,width:1.8});
      p.line(A,B,C.teal,2.8);
      if(!ok)p.line([-Math.min(half,A[0]),A[1]],[Math.min(half,A[0]),A[1]],C.red,3.6);
      p.dot(A,C.blue);p.dot(B,C.blue);
    },xy);
    const shapes=[[M('|x|'),x=>Math.abs(x)],[M('\\max\\{|x|-1,0\\}'),x=>Math.max(Math.abs(x)-1,0)],
      [M('x^4-2x^2+0.3x'),x=>x**4-2*x*x+.3*x]];
    return panel('凸多边形',g1)+panel('非凸上半圆环',g2)+shapes.map(([title,f],i)=>{
      const a=[s.l,f(s.l)],b=[s.r,f(s.r)];
      return panel(title,chart('函数与弦线',[-1.6,1.6,-1.7,2],p=>{
        p.curve(f,-1.6,1.6,C.blue);
        p.line(a,b,C.teal,2.5);
        const points=seq(0,1,180).map(t=>mix(a,b,t));
        const test=points.map(([x,y])=>f(x)>y+1e-8?[x,y]:null);
        p.path(test,C.red,{width:3.8});
        p.dot(a,C.blue,6,false,'l');p.dot(b,C.blue,6,false,'r');
      },{x:'x',y:'f(x)'}),{key:'curve'+i,legends:legend(['曲线',C.blue],['合格弦段',C.teal],['违规弦段',C.red])});
    }).join('');
  },{drag:(_,key,p)=>key==='l'?{l:clamp(p[0],-1.45,-.05)}:key==='r'?{r:clamp(p[0],.05,1.45)}:null}),

  '02-2':model({theta:.18},[
    range('theta','混合比例 θ',.01,1,.01),preset('邻域内',{theta:.18}),
    preset('邻域边缘',{theta:.32}),preset('远处点',{theta:1})
  ],s=>{
    const f=u=>.3*(u-3.5)**2+1,x=[1,f(1)],y=[3.5,f(3.5)],mid=mix(x,y,s.theta),z=[mid[0],f(mid[0])];
    return panel('开邻域与混合点',chart('凸曲线、弦和开邻域',[0,5,.75,4.85],p=>{
      p.area([[.2,.75],[1.8,.75],[1.8,4.85],[.2,4.85]],C.gray,.13);
      [.2,1.8].forEach(u=>p.line([u,.75],[u,4.85],C.gray,1,'4 4'));
      p.curve(f,0,5,C.blue);p.line(x,y,C.gold,2,'6 4');p.line(z,mid,C.red,1.5,'4 3');
      p.dot(x,C.blue);p.text(x,'x',C.blue,-15,-9);p.dot(y,C.teal);p.text(y,'y',C.teal,9,4);
      p.dot(mid,C.gold,4,true);p.dot(z,C.red,6);p.text(z,'xθ',C.red,10,19);
    },{x:'u',y:'f(u)'}),{wide:true,value:reading('x_\\theta='+fmt(mid[0]),'f(x_\\theta)='+fmt(z[1]))+
        '<span>'+(s.theta<.32?'开邻域内部':s.theta>.32?'开邻域外部':'开邻域边缘')+'</span>'});
  }),

  '03-1':model({u:.65,v:-.25,angle:34,px:.6,py:.4,slice:'yes'},[
    range('u','切点 x₁',-1.1,1.1,.02),range('v','切点 x₂',-1.1,1.1,.02),
    range('angle','观察方向',-90,110,1),choice('slice','一维截面',[['yes','显示'],['no','收起']]),
    range('px','可行测试点 x₁',-1,4,.05),range('py','可行测试点 x₂',-1,3,.05),
    preset('恢复视角',{angle:34})
  ],s=>{
    const f=(x,y)=>.5*x*x+y*y,pt=[s.u,s.v],h=f(...pt),g=[s.u,2*s.v],plane=(x,y)=>h+dot(g,minus([x,y],pt));
    const view=spatial('二次曲面及其切平面',[[-1.8,1.8],[-1.8,1.8],[-4.6,5.2]],{
      angle:s.angle, cells:[...mesh((x,y)=>[x,y,f(x,y)],[-1.8,1.8],[-1.8,1.8],22,21,C.blue,.23),
        ...mesh((x,y)=>[x,y,plane(x,y)],[-1.8,1.8],[-1.8,1.8],5,5,C.teal,.27)],
      segments:s.slice==='yes'?[{vertices:seq(-1.8,1.8,100).map(x=>[x,s.v,f(x,s.v)]),color:C.gold}]:[],
      points:[{at:[...pt,h],name:'x',color:C.red}]
    });
    const q=halfProjection([s.px,s.py],a0,b0),grad=minus(p0,z0);
    return panel('曲面与切平面',view,{legends:legend(['二次曲面',C.blue],['切平面',C.teal],['截面',C.gold]),
      value:reading('x='+vec(pt),'f(x)='+fmt(h))})+
      panel('边界最优性',chart('切点、梯度与可行位移',box0,p=>{
        halfPlane(p,a0,b0,C.teal);levels(p,[1,3,5,8,13],z0,Math.sqrt,Math.sqrt);
        p.arrow(p0,plus(p0,times(grad,.65)),C.blue,3);p.arrow(p0,minus(p0,times(grad,.65)),C.red,3);
        p.arrow(p0,q,C.teal,3);
        p.dot(p0,C.blue);p.text(p0,'x★',C.blue,-24,21);
        p.dot(q,C.teal,6,false,'q');p.text(q,'x',C.teal);
        p.text(plus(p0,times(grad,.65)),'∇f',C.blue,-27,-11);
        p.text(minus(p0,times(grad,.65)),'−∇f',C.red);
      },xy),{key:'boundary',value:reading('\\nabla f(x^\\star)^\\top(x-x^\\star)='+fmt(dot(grad,minus(q,p0))))})+
      (s.slice==='yes'?panel(M('x_2='+fmt(s.v)),chart('切平面截线与函数截面',[-1.8,1.8,-3,4],p=>{
        p.curve(x=>f(x,s.v),-1.8,1.8,C.blue);p.curve(x=>plane(x,s.v),-1.8,1.8,C.teal,{dash:'6 4'});p.dot([s.u,h],C.red);
      },{x:'x₁',y:'高度'}),{wide:true,legends:legend(['曲面截线',C.blue],['切平面截线',C.teal,true])}):'');
  },{drag:(_,key,p)=>key==='q'?{px:clamp(p[0],-1,4),py:clamp(p[1],-1,3)}:null}),

  '04-1':model({angle:38,rank:'plane',outlier:sampleY[5],rho:0},[
    choice('rank','列空间',[['plane','满列秩'],['near','近共线'],['line','列秩亏损']]),
    range('angle','观察方向',-90,110,1),range('outlier','第 6 个观测 y₆',-1,8,.02),range('rho','岭参数 ρ',0,5,.05),
    preset('原观测',{outlier:sampleY[5]}),preset('提高第 6 个观测',{outlier:7})
  ],s=>{
    const u=unit([1,0,.5]),v=unit([-1,2,2]),t=unit(minus(v,times(u,dot(u,v))));
    const obs=[1.4,-.55,2.2],project=plus(times(u,dot(u,obs)),times(t,s.rank==='line'?0:dot(t,obs)));
    const w=plus(u,times(t,s.rank==='near'?.12:1));
    const space=spatial('列空间、预测点与残差',[[-2.7,2.7],[-2.7,2.7],[-2.7,2.7]],{
      angle:s.angle,axes:['y₁','y₂','y₃'],
      cells:s.rank==='line'?[]:mesh((p,q)=>plus(times(u,p),times(t,q)),[-2.2,2.2],[-2,2],7,7,C.blue,.25),
      segments:[{vertices:[times(u,-2.6),times(u,2.6)],color:C.blue},
        {vertices:[[0,0,0],times(w,1.65)],color:C.teal,arrowhead:true},
        {vertices:[project,obs],color:C.red,dash:'5 4',arrowhead:true}],
      points:[{at:obs,name:'y'},{at:project,name:'ŷ',color:C.blue}]
    });
    const balls=chart('三个范数单位球',[-1.28,1.28,-1.28,1.28],p=>{
      for(const [shape,c] of [[[[1,1],[-1,1],[-1,-1],[1,-1]],C.violet],[circle([0,0],1),C.blue],
          [[[1,0],[0,1],[-1,0],[0,-1]],C.teal]]) {p.area(shape,c,.11);p.path(shape,c,{close:true});}
    },{...xy,x:'r₁',y:'r₂'});
    const funcs=[[u=>u*u,C.blue], [Math.abs,C.teal],[huber,C.red],[deadZone,C.gold]];
    const loss=chart('四种惩罚函数',[-3,3,-.15,9.5],p=>funcs.forEach(([f,c])=>p.curve(f,-3,3,c)),{x:'u',y:'φ(u)'});
    const y=[...sampleY.slice(0,5),s.outlier];
    const fits=[ridge(sampleX,y),fitPiecewise(sampleX,y),fitHuber(sampleX,y),fitPiecewise(sampleX,y,1)];
    const fitted=chart('六个观测点与四种拟合',[-3,3,-3,8.6],p=>{
      fits.forEach(([b,m],i)=>p.curve(x=>b+m*x,-3,3,funcs[i][1],{dash:i===3?'5 4':''}));
      sampleX.forEach((x,i)=>p.dot([x,y[i]],i===5?C.red:C.ink,5,false,i===5?'outlier':''));
    },{x:'输入',y:'观测'});
    const inputs=s.rank==='line'?sampleX.map(()=>1):s.rank==='near'?sampleX.map(x=>1+.13*x):sampleX;
    const sys=normalSystem(inputs,y), [b,m]=ridge(inputs,y,s.rho);
    const {angle,eigenvalues}=spectral(sys.q);
    const span=s.rank==='near'?6:3.1;
    const contours=chart('参数空间中的岭回归等高线',[b-span,b+span,m-span,m+span],p=>{
      if(s.rank==='line' && s.rho===0) {
        for(const v of [0,.5,1,1.5]) for(const sign of v?[-1,1]:[1]) {
          boundary(p,[1,1],b+m+v*sign,v?C.gray:C.blue,v?'5 4':'');
        }
      } else {
        levels(p,[.5,2,5,9],[b,m],v=>Math.sqrt(2*v/(eigenvalues[0]+s.rho)),v=>Math.sqrt(2*v/(eigenvalues[1]+s.rho)),angle);
      }
      p.dot([b,m],C.red);p.text([b,m],s.rank==='line'&&s.rho===0?'最小范数解':'x★',C.red);
    },{...xy,x:'截距',y:'斜率'});
    const losses=legend([M('u^2'),C.blue],[M('|u|'),C.teal],['Huber',C.red],['死区',C.gold,true]);
    return panel('列空间上的正交投影',space,{value:reading('\\|y-\\hat y\\|_2='+fmt(norm(minus(obs,project))))})+
      panel('三种单位球',balls,{legends:legend([M('\\ell_1'),C.teal],[M('\\ell_2'),C.blue],[M('\\ell_\\infty'),C.violet])})+
      panel('四种残差惩罚',loss,{legends:losses})+
      panel('拟合与第六个观测',fitted,{key:'fit',legends:losses,value:reading('y_6='+fmt(s.outlier))})+
      panel('岭回归的参数等高线',contours,{wide:true,value:reading('\\rho='+fmt(s.rho),'x^\\star='+vec([b,m]),'E='+fmt(squaredError(inputs,y,[b,m])))});
  },{drag:(_,key,p)=>key==='outlier'?{outlier:clamp(p[1],-1,8)}:null}),
};

import {dot, plus, times} from './plot.mjs';

export const sampleX = [-2.5,-1.5,-.5,.5,1.5,2.5];
export const sampleY = [-1.5,-.72,.12,.74,1.38,2.24];
export const huber = u => Math.abs(u)<=1 ? u*u/2 : Math.abs(u)-.5;
export const deadZone = u => Math.max(Math.abs(u)-1,0);

export function normalSystem(x,y,weights=x.map(()=>1)) {
  const w0 = weights.reduce((a,b)=>a+b,0), w1 = dot(weights,x);
  return {
    q:[[w0,w1],[w1,x.reduce((sum,t,i)=>sum+weights[i]*t*t,0)]],
    c:[dot(weights,y),x.reduce((sum,t,i)=>sum+weights[i]*t*y[i],0)],
  };
}
export function spectral([[a,b],[,d]]) {
  const angle = Math.atan2(2*b,a-d)/2;
  const middle=(a+d)/2, radius=Math.hypot((a-d)/2,b);
  const major=[Math.cos(angle),Math.sin(angle)];
  return {angle,eigenvalues:[middle+radius,middle-radius],vectors:[major,[-major[1],major[0]]]};
}
export function ridge(x,y,rho=0,weights) {
  const {q,c}=normalSystem(x,y,weights);
  const {eigenvalues,vectors}=spectral(q);
  return eigenvalues.reduce((z,e,i)=>e+rho>1e-10 ?
    plus(z,times(vectors[i],dot(vectors[i],c)/(e+rho))) : z,[0,0]);
}
export const residuals = (x,y,[b,m])=>x.map((t,i)=>b+m*t-y[i]);
export const squaredError = (x,y,z)=>dot(residuals(x,y,z),residuals(x,y,z))/2;

export function fitHuber(x,y) {
  let z=ridge(x,y);
  for(let i=0;i<500;i++) {
    const r=residuals(x,y,z);
    const candidate=ridge(x,y,0,r.map(t=>1/Math.max(1,Math.abs(t))));
    if(Math.hypot(candidate[0]-z[0],candidate[1]-z[1])<1e-11) return candidate;
    z=candidate;
  }
  return z;
}
export function fitPiecewise(x,y,zone=0) {
  const shifts=zone?[-zone,zone]:[0];
  let best=ridge(x,y), cost=Infinity;
  for(let i=0;i<x.length;i++) for(let j=i+1;j<x.length;j++) {
    if(x[i]===x[j]) continue;
    for(const u of shifts) for(const v of shifts) {
      const m=(y[j]+v-y[i]-u)/(x[j]-x[i]), z=[y[i]+u-m*x[i],m];
      const loss=residuals(x,y,z).reduce((s,r)=>s+Math.max(Math.abs(r)-zone,0),0);
      if(loss<cost-1e-10) {cost=loss;best=z;}
    }
  }
  return best;
}

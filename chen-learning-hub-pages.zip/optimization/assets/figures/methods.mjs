import {C, above, bars, boundary, chart, choice, clamp, dot, fmt, halfPlane, halfProjection,
  labelMath as M, legend, levels, mix, model, norm, panel, perp, pi, plus, polar, preset,
  range, reading, seq, times, minus, unit, vec} from './plot.mjs';
import * as P1 from './p1.mjs';
const xy={equal:true,x:'x₁',y:'x₂'};
const tPlot={x:'t',y:'高度'};
const tau=2*pi;

function backtrack(alpha,beta) {
  const f=t=>1-1.5*t+1.2*t*t, check=t=>1-1.5*alpha*t, tries=[];
  for(let t=1;tries.length<40;t*=beta) {
    const ok=f(t)<=check(t)+1e-12;
    tries.push({t,ok,value:f(t)});
    if(ok) break;
  }
  return {tries,f,check,threshold:1.5*(1-alpha)/1.2};
}
function trajectory(gamma,mode,ratio,count=22) {
  const points=[[gamma,1]];
  for(let i=0;i<count;i++) {
    const x=points.at(-1), g=[x[0],gamma*x[1]];
    if(norm(g)<1e-12) break;
    const t=mode==='exact'?dot(g,g)/(g[0]**2+gamma*g[1]**2):ratio/gamma;
    points.push(minus(x,times(g,t)));
  }
  return points;
}
const avg = points => points.reduce((a,b)=>a+b,0)/points.length;

export const methods = {
  '05-1':model({angle:pi},[
    range('angle','相对梯度的转角 θ',0,tau,.01),preset('同向',{angle:0}),
    preset('相切',{angle:pi/2}),preset('反向',{angle:pi})
  ],s=>{
    const x=[1.5,1],g=[1.5,3],len=norm(g),phi=Math.atan2(3,1.5),u=polar(phi+s.angle),q=plus(x,u);
    const v=dot(g,u);
    return panel('单位方向圆',chart('等高线、梯度与单位方向',[-2.4,4.1,-1.6,4.7],p=>{
      levels(p,[.5,1.2,2.625,4.5,7,10],[0,0],v=>Math.sqrt(2*v),v=>Math.sqrt(2*v/3));
      p.ring(x,1,C.gray,{dash:'5 4',width:1.8});
      [0,pi/2,pi].forEach(a=>p.arrow(x,plus(x,polar(a+phi)),C.gray,1.45,'3 3'));
      p.arrow(x,plus(x,g),C.red,3);
      p.arrow(x,q,C.blue,3);p.dot(x,C.ink);p.text(x,'x',C.ink,10,19);
      p.dot(q,C.blue,6,false,'direction');p.text(q,'u',C.blue);
      p.text(plus(x,g),'∇f',C.red);
    },xy),{key:'unit',legends:legend(['梯度',C.red],['单位方向',C.blue])})+
    panel('方向导数',chart('梯度与单位方向的内积',[0,tau,-3.85,3.85],p=>{
      p.curve(t=>len*Math.cos(t),0,tau,C.blue);
      for(const a of [0,pi/2,pi,3*pi/2]) p.dot([a,len*Math.cos(a)],C.gray,4,true);
      p.line([s.angle,-3.85],[s.angle,v],C.gold,1.8,'5 4');p.dot([s.angle,v],C.red,6);
    },{x:'θ',y:'∇fᵀu',xt:[0,pi/2,pi,3*pi/2,tau],xTick:t=>['0','π/2','π','3π/2','2π'][Math.round(t/(pi/2))]}),
    {value:reading('\\nabla f^\\top u='+fmt(v),'\\|\\nabla f\\|_2=\\sqrt{11.25}')});
  },{drag:(_,key,p)=>key==='direction'?{angle:(Math.atan2(p[1]-1,p[0]-1.5)-Math.atan2(3,1.5)+tau)%tau}:null}),

  '05-2':model({t:.5},[
    range('t','步长 t',0,1.4,.01),preset('上盖谷底',{t:.5}),preset('临界步长',{t:1}),preset('越界',{t:1.2})
  ],s=>{
    const phi=t=>1-2*t+t*t, T=t=>1-2*t, U=t=>1-2*t+2*t*t;
    return panel('三条曲线与初始高度',chart('切线预测、真实函数、二次上盖',[0,1.4,-1.9,2.35],p=>{
      p.area([[0,-1.9],[1,-1.9],[1,1],[0,1]],C.blue,.07);
      p.line([0,1],[1.4,1],C.gray,1.6,'4 5');
      p.curve(T,0,1.4,C.gray,{dash:'7 5'});p.curve(phi,0,1.4,C.blue);p.curve(U,0,1.4,C.red);
      [[.5,.5],[1,1],[1.2,U(1.2)]].forEach(pt=>p.dot(pt,C.red,4,true));
      p.line([s.t,-1.9],[s.t,U(s.t)],C.gold,1.5,'4 4');
      [[T(s.t),C.gray],[phi(s.t),C.blue],[U(s.t),C.red]].forEach(([v,c])=>p.dot([s.t,v],c,5));
    },tPlot),{wide:true,legends:legend(['切线预测',C.gray,true],['真实函数',C.blue],['二次上盖',C.red]),
      value:reading('\\phi(t)='+fmt(phi(s.t)),'U(t)='+fmt(U(s.t)))+bars([['一次收益',2*s.t,C.blue],['二次代价',2*s.t*s.t,C.gold]])});
  }),

  '05-3':model({alpha:.3,beta:.6,n:40},[
    range('alpha','α',.05,.49,.01),range('beta','β',.15,.9,.01),
    preset('显示第一步',{n:1}),preset('下一次试探',s=>({n:Math.min(s.n+1,backtrack(s.alpha,s.beta).tries.length)})),
    preset('完整回溯',{n:40})
  ],s=>{
    const {tries,f,check,threshold}=backtrack(s.alpha,s.beta),visible=tries.slice(0,s.n);
    return panel('Armijo 检验',chart('射线函数与 Armijo 检验线',[0,1.2,-.85,1.2],p=>{
      p.curve(t=>1-1.5*t,0,1.2,C.gray,{dash:'6 4'});p.curve(check,0,1.2,C.gold,{dash:'6 4'});p.curve(f,0,1.2,C.blue);
      if(threshold<=1.2) {
        p.line([threshold,-.85],[threshold,f(threshold)],C.gray,1.4,'4 4');
        p.dot([threshold,f(threshold)],C.gold,4,true);
      }
      for(const {t,ok,value} of visible){
        const c=ok?C.teal:C.red;
        p.line([t,check(t)],[t,value],c,1.6,'4 3');p.dot([t,value],c,6);
        p.text([t,value],ok?'接受':'拒绝',c,t>.89?-40:10,ok?22:-10);
      }
    },tPlot),{wide:true,legends:legend(['真实曲线',C.blue],['切线',C.gray,true],['检验线',C.gold,true]),
      value:reading('t_0='+fmt(threshold),...(tries.length>1?['[\\beta t_0,t_0]='+ '['+fmt(s.beta*threshold)+','+fmt(threshold)+']']:[]))+
        '<div class="plot-legend">'+visible.map(({t,ok})=>'<span>'+fmt(t)+' · '+(ok?'接受':'拒绝')+'</span>').join('')+'</div>'});
  }),

  '06-1':model({gamma:10,mode:'exact',ratio:1.1},[
    range('gamma','椭圆碗 γ',1,20,1),choice('mode','步长规则',[['exact','精确线搜索'],['fixed','固定步长']]),
    range('ratio','固定步长 ηγ',.1,1.9,.05),preset('圆碗与狭长碗',{gamma:10,mode:'exact'})
  ],s=>{
    function draw(gamma,title) {
      const pts=trajectory(gamma,s.mode,s.ratio);
      return panel(title,chart(title,[-1.35,gamma+1.35,-1.75,1.75],p=>{
        const E=(gamma*gamma+gamma)/2;
        levels(p,[.02,.10,.3,.55,1].map(r=>r*E),[0,0],v=>Math.sqrt(2*v),v=>Math.sqrt(2*v/gamma),0,C.gray);
        p.path(pts,C.blue,{width:2.75});
        pts.slice(0,9).forEach((q,i)=>p.dot(q,i===0?C.red:C.blue,i===0?5.5:4));
        p.dot([0,0],C.teal,5);p.text([0,0],'x★',C.teal,-27,19);
      },xy),{value:reading('\\gamma='+gamma,'x_0='+vec([gamma,1]),...(s.mode==='fixed'?['\\eta='+fmt(s.ratio/gamma)]:[]),'k='+ (pts.length-1))});
    }
    return draw(1,'正圆碗')+draw(s.gamma,'椭圆碗');
  }),

  '06-2':model({v:1.5},[
    range('v','读数 v',-2.5,3.25,.01),preset('下托最低点',{v:-1.5}),preset('真实最低点',{v:0}),preset('上盖最低点',{v:.75})
  ],s=>{
    const u=1.5,f=v=>v*v,T=v=>2.25+3*(v-u),L=v=>T(v)+.5*(v-u)**2,U=v=>T(v)+2*(v-u)**2;
    return panel('同一切点的三条曲线',chart('二次下托、真实函数与二次上盖',[-2.6,3.3,-3,10.5],p=>{
      p.curve(T,-2.6,3.3,C.gray,{width:1.5,dash:'5 5'});p.curve(L,-2.6,3.3,C.teal);p.curve(f,-2.6,3.3,C.blue);p.curve(U,-2.6,3.3,C.red);
      [[-1.5,-2.25,C.teal],[0,0,C.blue],[.75,1.125,C.red]].forEach(([x,y,c])=>{
        p.line([-2.6,y],[x,y],c,1.1,'4 4');p.dot([x,y],c,5,true);
      });
      p.dot([u,f(u)],C.gold);p.text([u,f(u)],'u',C.gold,11,15);
      p.line([s.v,-3],[s.v,10.5],C.gray,1.3,'5 5');
      [[L,C.teal],[f,C.blue],[U,C.red]].forEach(([F,c])=>p.dot([s.v,F(s.v)],c));
    },{x:'v',y:'高度'}),{wide:true,legends:legend(['二次下托 μ = 1',C.teal],['真实函数',C.blue],['二次上盖 L = 4',C.red],['切线',C.gray,true]),
      value:reading('v='+fmt(s.v),fmt(L(s.v))+'\\le f(v)='+fmt(f(s.v))+'\\le'+fmt(U(s.v)))});
  }),

  '06-3':model({k:12,active:'all'},[
    range('k','迭代次数 k',0,30,1),choice('active','高亮条件数',[['all','全部'],['2','κ = 2'],['5','κ = 5'],['20','κ = 20']])
  ],s=>{
    const ks=[2,5,20],colors=[C.blue,C.teal,C.violet];
    const series=ks.map(kappa=>{
      const n=Math.sqrt(2/(kappa*kappa+kappa)),x0=kappa*n,y0=n,ratio=1-1/kappa;
      return seq(0,30,30).map(k=>({k,E:k===0?(x0*x0+kappa*y0*y0)/2:.5*(x0*ratio**k)**2,bound:ratio**k}));
    });
    function draw(log) {
      const y=e=>log?Math.log10(e):e;
      return panel(log?'半对数坐标':'普通坐标',chart('真实误差与理论上界',[0,30,log?-19:0,log?.5:1.08],p=>{
        const target=y(1e-4);
        p.line([0,target],[30,target],C.gray,1.4,'4 4');
        p.line([s.k,log?-19:0],[s.k,log?.5:1.08],C.gold,1.3,'4 4');
        series.forEach((values,i)=>{
          const active=s.active==='all'||+s.active===ks[i],opts={opacity:active?1:.23};
          p.path(values.map(v=>[v.k,y(v.bound)]),colors[i],{...opts,dash:'5 5',width:1.55});
          p.path(values.map(v=>[v.k,y(v.E)]),colors[i],{...opts,width:2.8});
          if(active)p.dot([s.k,y(values[s.k].E)],colors[i],4.8);
        });
      },{x:'k',y:log?'log₁₀ E':'E'}),{legends:legend(...ks.map((k,i)=>['κ = '+k,colors[i]]),['理论界',C.gray,true]),
        value:reading('k='+s.k,...series.map((vs,i)=>'E_{'+ks[i]+'}='+vs[s.k].E.toPrecision(3).replace(/e([+-]?\d+)/,'\\times 10^{$1}')))});
    }
    return draw(false)+draw(true);
  }),

  '07-1':model({u:1,h:.6},[
    range('u','沿边界的位移',-2.1,2.1,.02),range('h','进入可行域的深度',0,1.5,.02),
    preset('边界点',{u:1,h:0}),preset('内部点',{u:1,h:.6}),preset('重合点',{u:0,h:0})
  ],s=>{
    const z=[2,2],a=[1,2],b=4,p0=halfProjection(z,a,b),x=plus(p0,minus(times(unit(perp(a)),s.u),times(unit(a),s.h)));
    const u=minus(z,p0),v=minus(x,p0),dp=dot(u,v),angle=norm(v)>1e-10?Math.acos(clamp(dp/(norm(u)*norm(v)),-1,1)):null;
    return panel('闭凸半空间的唯一投影',chart('投影特征不等式',[-1.2,4,-1.2,3.45],p=>{
      halfPlane(p,a,b,C.teal);p.ring(z,norm(u),C.gold,{dash:'5 4'});
      p.arrow(p0,z,C.red,3);p.arrow(p0,x,C.blue,3);p.right(p0,z,x);
      p.dot(z,C.red);p.text(z,'z',C.red);
      p.dot(p0,C.teal);p.text(p0,'p',C.teal,-15,19);
      p.dot(x,C.blue);if(norm(v)>1e-10)p.text(x,'x',C.blue);
    },xy),{value:reading('p='+vec(p0),'(z-p)^\\top(x-p)='+fmt(dp),...(angle===null?[]:['\\angle='+fmt(angle*180/pi,1)+'^\\circ']))})+
    panel('非凸集合的两个最近点',chart('两个区间与单位接触圆',[-2.45,2.45,-1.25,1.25],p=>{
      p.ring([0,0],1,C.gold,{dash:'5 4'});
      p.line([-2,0],[-1,0],C.teal,6);p.line([1,0],[2,0],C.teal,6);
      [-2,-1,1,2].forEach(t=>p.dot([t,0],C.teal,5.5));
      p.dot([0,0],C.red);p.text([0,0],'z',C.red,6,-10);
      p.text([-1,0],'−1',C.teal,-19,-13);p.text([1,0],'1',C.teal,9,-13);
    },xy),{value:reading('C=[-2,-1]\\cup[1,2]','\\{-1,1\\}')});
  }),

  '07-2':model({u:2,v:0,x:0,y:2},[
    range('u','u₁',-2.6,2.6,.02),range('v','u₂',-2.6,2.6,.02),
    range('x','v₁',-2.6,2.6,.02),range('y','v₂',-2.6,2.6,.02),
    preset('投影重合',{u:2,v:0,x:1.5,y:0})
  ],s=>{
    const u=[s.u,s.v],v=[s.x,s.y],project=p=>times(p,1/Math.max(1,norm(p))),a=project(u),b=project(v),d=minus(b,a);
    return panel('原距离与投影距离',chart('单位闭圆盘的非扩张投影',[-3,3,-3,3],p=>{
      p.ring([0,0],1,C.teal,{fill:C.teal,opacity:.17});p.ring([0,0],1,C.teal,{width:2});
      if(norm(d)>1e-8) [a,b].forEach(q=>boundary(p,d,dot(d,q),C.gray,'4 5'));
      p.line(a,u,C.gray,1.5,'4 4');p.line(b,v,C.gray,1.5,'4 4');
      p.line(u,v,C.red,2.8);p.line(a,b,C.blue,2.8);
      for(const [q,n,c,key] of [[u,'u',C.red,'u'],[v,'v',C.red,'v'],[a,'Πu',C.blue,''],[b,'Πv',C.blue,'']]){
        p.dot(q,c,key?6:4.8,false,key);p.text(q,n,c,n==='v'||n==='Πv'?-29:10,n==='Πv'?18:-9);
      }
    },xy),{key:'projection',wide:true,value:reading('\\|\\Pi_C u-\\Pi_C v\\|_2='+fmt(norm(d)), '\\|u-v\\|_2='+fmt(norm(minus(u,v))))});
  },{drag:(_,key,p)=>key==='u'?{u:clamp(p[0],-2.6,2.6),v:clamp(p[1],-2.6,2.6)}:
    key==='v'?{x:clamp(p[0],-2.6,2.6),y:clamp(p[1],-2.6,2.6)}:null}),

  '07-3':model({t:.38,k:0},[
    range('t','普通边界点 x₁',-.7,2.45,.01),
    preset('再走一步',s=>({k:Math.min(18,s.k+1)})),preset('回到起点',{k:0})
  ],s=>{
    const optimum=P1.budget(P1.b0).x, path=[[s.t,P1.b0-s.t]];
    for(let j=0;j<s.k;j++)path.push(P1.step(path.at(-1)).next);
    function draw(x,title,pts) {
      const {trial,next}=P1.step(x);
      return panel(title,chart(title,[-1.05,3.1,-2.05,2.35],p=>{
        halfPlane(p,P1.a,P1.b0,C.teal);P1.ellipses(p,[.25,.7,1.4,2.8,5]);
        if(pts.length>1)p.path(pts,C.blue,{width:3});
        p.dot(P1.z,C.gray,5,true);p.text(P1.z,'z',C.gray);
        p.dot(optimum,C.teal,5);p.text(optimum,'x★',C.teal,10,17);
        p.arrow(x,trial,C.red,3);p.arrow(trial,next,C.blue,2.7,'5 3');
        p.dot(trial,C.red);p.text(trial,'试探点',C.red,8,-9);
        p.dot(x,C.ink,5);p.dot(next,C.blue,5,true);
        if(norm(minus(x,next))>1e-4)p.text(next,'投影点',C.blue,6,23);
      },xy),{legends:legend(['负梯度步',C.red],['欧氏拉回',C.blue,true]),
        value:reading('\\eta=1/L','\\|T(x)-x\\|_2='+fmt(norm(minus(x,next)),6))});
    }
    return draw(path.at(-1),'普通边界点',path)+draw(optimum,'边界最优点',[]);
  }),

  '08-1':model({k:8,eta:.2},[
    range('k','平均的点数 K',1,24,1),preset('再取一个迭代点',s=>({k:Math.min(24,s.k+1)})),
    range('eta','右图步长 η',.02,.8,.01),preset('右图最优步长',{eta:.2})
  ],s=>{
    const f=x=>Math.sqrt(x*x+.01),a=Math.sqrt(.03),iter=[a];
    for(let j=1;j<s.k;j++)iter.push(iter.at(-1)-.4*iter.at(-1)/f(iter.at(-1)));
    const x=iter.at(-1),mean=avg(iter);
    const A=t=>.02/t,B=t=>.5*t,T=t=>A(t)+B(t);
    return panel('单点震荡与历史平均',chart('原函数上的二周期与平均点',[-.42,.42,.08,.46],p=>{
      p.curve(f,-.42,.42,C.blue);p.line([-a,.2],[a,.2],C.gray,1.6,'4 4');
      [-a,a].forEach(t=>p.dot([t,f(t)],C.blue,5,true));
      p.dot([x,f(x)],C.red,6);p.text([x,f(x)],'xK',C.red,x>0?10:-29,-11);
      p.dot([mean,f(mean)],C.teal,6);p.text([mean,f(mean)],'平均点',C.teal,9,18);
    },{x:'x',y:'f(x)'}),{value:reading('x_K='+fmt(x),'\\bar{x}_K='+fmt(mean),'f(\\bar{x}_K)='+fmt(f(mean)))})+
    panel('两项步长代价',chart('误差上界与步长',[.02,.8,0,1.08],p=>{
      p.curve(A,.02,.8,C.teal,{dash:'6 4'});p.curve(B,.02,.8,C.gold,{dash:'6 4'});p.curve(T,.02,.8,C.blue);
      p.dot([.2,.2],C.red,5,true);p.text([.2,.2],'(0.2, 0.2)',C.red,10,23);
      p.line([s.eta,0],[s.eta,T(s.eta)],C.gray,1.4,'5 5');p.dot([s.eta,T(s.eta)],C.blue,5);
    },{x:'η',y:'误差上界'}),{legends:legend([M('0.02/\\eta'),C.teal,true],[M('0.5\\eta'),C.gold,true],['总和',C.blue]),value:reading('T(\\eta)='+fmt(T(s.eta)))});
  }),
};

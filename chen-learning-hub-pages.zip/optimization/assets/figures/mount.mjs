import {escape,fmt} from './plot.mjs';
const groups = [
  [4,'early'],[8,'methods'],[11,'reformulate'],[14,'certificates'],[18,'advanced']
];

export async function mountFigure(root, metadata) {
  if(root.dataset.mounted) return;
  root.dataset.mounted='loading';
  const id=root.dataset.figure;
  const group=groups.find(([end])=>Number(id.slice(0,2))<=end)?.[1];
  const library=await import('./'+group+'.mjs');
  if(!root.isConnected) return;
  const m=library[group][id];
  if(!m) throw Error('Missing figure '+id);
  let state={...m.initial};
  root.innerHTML='<figure class="course-figure"><figcaption class="figure-heading"><strong>图 '+id+
    '</strong><div><button type="button" data-command="expand-figure">放大图像</button>'+
    '<button type="button" data-command="svg">导出 SVG</button></div></figcaption>'+
    '<div class="fig-controls"></div><div class="plot-grid"></div>'+
    (metadata?.altHTML?'<details class="visual-alt"><summary>图像文字说明</summary><p id="'+id+'-alt">'+metadata.altHTML+'</p></details>':'')+
    '</figure>';
  const controls=root.querySelector('.fig-controls');
  const grid=root.querySelector('.plot-grid');
  const setters=[];
  function render() {
    grid.innerHTML=m.render(state);
    if(metadata?.altHTML) for(const svg of grid.querySelectorAll('svg')) svg.setAttribute('aria-describedby',id+'-alt');
    for(const sync of setters) sync();
  }
  function update(changes) {
    if(changes) {Object.assign(state,changes);render();}
  }
  const controlList=document.createElement('div'),buttons=document.createElement('div');
  controlList.className='sliders';buttons.className='figure-presets';
  for(const control of m.controls) {
    if(control.type==='button') {
      const button=document.createElement('button');button.type='button';button.textContent=control.label;
      button.addEventListener('click',()=>update(control.change(state)));buttons.append(button);
      continue;
    }
    const label=document.createElement('label');
    label.className='control-label';
    const caption=document.createElement('span');caption.textContent=control.label;label.append(caption);
    if(control.type==='range') {
      const input=document.createElement('input');
      const output=document.createElement('output');
      Object.assign(input,{type:'range',min:control.min,max:control.max,step:control.step});
      input.setAttribute('aria-label',control.label);
      input.addEventListener('input',()=>update({[control.key]:Number(input.value)}));
      label.append(output,input);
      setters.push(()=>{
        const value=state[control.key];
        if(Math.abs(+input.value-value)>control.step/2+1e-8) input.value=value;
        output.value=fmt(value,4);
        input.setAttribute('aria-valuetext',fmt(value,4));
      });
    } else {
      const select=document.createElement('select');
      select.setAttribute('aria-label',control.label);
      for(const [value,title] of control.options) select.add(new Option(title,value));
      select.addEventListener('change',()=>update({[control.key]:select.value}));
      label.append(select);setters.push(()=>{select.value=state[control.key];});
    }
    controlList.append(label);
  }
  const reset=document.createElement('button');reset.type='button';reset.className='plot-reset';reset.textContent='重置';
  reset.addEventListener('click',()=>{state={...m.initial};render();});
  buttons.append(reset);controls.append(controlList,buttons);
  render();
  root.dataset.mounted='yes';

  if(m.drag) {
    let drag=null;
    grid.addEventListener('pointerdown',event=>{
      const handle=event.target.closest('[data-drag]');
      if(!handle||event.button!==0) return;
      const svg=handle.closest('svg');
      drag={key:handle.dataset.drag, panel:svg.closest('[data-panel]').dataset.panel, id:event.pointerId};
      grid.setPointerCapture(event.pointerId);
      event.preventDefault();
    });
    grid.addEventListener('pointermove',event=>{
      if(!drag||event.pointerId!==drag.id) return;
      const panel=Array.from(grid.querySelectorAll('[data-panel]')).find(el=>el.dataset.panel===drag.panel);
      const svg=panel?.querySelector('svg[data-coords]');
      const matrix=svg?.getScreenCTM();
      if(!matrix) return;
      const at=new DOMPoint(event.clientX,event.clientY).matrixTransform(matrix.inverse());
      const [a,b,sx,sy,xmin,ymin]=svg.dataset.coords.split(',').map(Number);
      update(m.drag(state,drag.key,[xmin+(at.x-a)/sx,ymin+(b-at.y)/sy],drag.panel));
    });
    const end=event=>{if(drag?.id===event.pointerId)drag=null;};
    grid.addEventListener('pointerup',end);
    grid.addEventListener('pointercancel',end);
    grid.addEventListener('lostpointercapture',end);
  }
}

export function saveFigure(root,id) {
  const diagrams=[...root.querySelectorAll('svg.math-plot')];
  if(!diagrams.length)return;
  const vars=['--ink','--line','--soft','--paper','--graph-blue','--graph-teal','--graph-violet','--graph-red','--graph-gold','--graph-gray'];
  const computed=getComputedStyle(root),bg=computed.getPropertyValue('--paper');
  const theme=vars.map(name=>name+':'+computed.getPropertyValue(name)).join(';');
  let width=0,height=0,content='';
  for(const source of diagrams) {
    const el=source.cloneNode(true), box=source.viewBox.baseVal;
    el.setAttribute('x',12);el.setAttribute('y',height+12);
    el.setAttribute('width',box.width);el.setAttribute('height',box.height);
    width=Math.max(width,box.width);
    height+=box.height+12;
    content+=new XMLSerializer().serializeToString(el);
  }
  const svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+(width+24)+' '+(height+12)+
    '" style="'+escape(theme)+'"><title>图 '+escape(id)+'</title><style>text{font-family:system-ui,sans-serif}.plot-label{paint-order:stroke;stroke:var(--paper);stroke-width:3;stroke-linejoin:round}</style>'+
    '<rect width="100%" height="100%" fill="'+escape(bg)+'"/>'+content+'</svg>';
  const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='optimization-'+id+'.svg';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

import {dot, plus, minus, times, halfProjection} from './plot.mjs';

// A=[sqrt(3) 1/sqrt(3); 0 sqrt(2/3)], rho=1, y=A^(-T)Qz.
// This instance is shared by the projected iteration and budget sensitivity.
export const Q = [[4,1],[1,2]];
export const z = [1.6,.4];
export const a = [1,1];
export const qA = [1/7,3/7];
export const s = dot(a,qA);
export const eta = 1/(3+Math.SQRT2);
export const Fz = 1.8;
export const b0 = 1;
export const matvec = (matrix,v) => matrix.map(row=>dot(row,v));
export function budget(b) {
  const lambda = Math.max(0,dot(a,z)-b)/s;
  return {lambda,x:minus(z,times(qA,lambda)),value:Fz+lambda*lambda*s/2};
}
export function gradient(x) {
  return matvec(Q,minus(x,z));
}
export function step(x,b=b0) {
  const trial=minus(x,times(gradient(x),eta));
  return {trial,next:halfProjection(trial,a,b)};
}
export function ellipses(p,values) {
  for(const value of values) p.path(Array.from({length:129},(_,i)=>{
    const theta=2*Math.PI*i/128;
    const u=Math.sqrt(2*value/(3+Math.SQRT2))*Math.cos(theta);
    const v=Math.sqrt(2*value/(3-Math.SQRT2))*Math.sin(theta);
    const ca=Math.cos(Math.PI/8),sa=Math.sin(Math.PI/8);
    return plus(z,[ca*u-sa*v,sa*u+ca*v]);
  }),'var(--graph-gray)',{width:1.15,opacity:.6});
}

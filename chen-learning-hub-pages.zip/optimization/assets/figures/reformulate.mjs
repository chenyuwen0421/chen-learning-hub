import {C, above, arrow, bars, boundary, chart, choice, clamp, clip, dot, fmt, labelMath as M, legend,
  line, mix, model, panel, path, point, plus, preset, range, reading, seq, svg, text, times, vec} from './plot.mjs';
import {mesh,spatial} from './space.mjs';

const cap = x=>Math.max(Math.abs(x-1),Math.abs(2*x+.5),Math.abs(-.8*x+1.2));
const poly=[[0,0],[3,0],[3,1],[0,4]];
const thresholdPlanes=t=>[[[-1,-t],2*t-4],[[-t,-1],2*t-4]];
export function thresholdSet(t) {
  return thresholdPlanes(t).reduce((p,[a,b])=>clip(p,a,b),poly);
}
function bisect(n) {
  let low=.3,high=1.4;
  for(let k=0;k<n;k++) {
    const mid=(low+high)/2;
    if(thresholdSet(mid).length)high=mid;
    else low=mid;
  }
  const mid=(low+high)/2, feasible=thresholdSet(high);
  const witness=times(feasible.reduce(plus,[0,0]),1/feasible.length);
  return {low,high,mid,witness};
}
const x2y={x:'x₁',y:'x₂',equal:true};

export const reformulate = {
  '09-1':model({x:.25,t:1},[
    range('x','横坐标 x',-2,2,.01),range('t','上盖高度 t',0,5,.02),
    preset('低于上包络',s=>({t:cap(s.x)-.45})),preset('压紧上盖',s=>({t:cap(s.x)})),
    preset('高于上包络',s=>({t:cap(s.x)+.45})),preset('最优点',{x:.25,t:1})
  ],s=>{
    const f=[x=>Math.abs(x-1),x=>Math.abs(2*x+.5),x=>Math.abs(-.8*x+1.2)];
    const values=f.map(fn=>fn(s.x)), top=Math.max(...values), accepted=s.t>=top-1e-9;
    return panel('上包络与上图',chart('三个残差和可行上盖',[-2,2,0,5.15],p=>{
      above(p,cap,-2,2,5.15,C.blue);
      f.forEach((fn,i)=>p.curve(fn,-2,2,[C.teal,C.violet,C.gold][i],{dash:'5 4',width:1.8}));
      p.curve(cap,-2,2,C.blue,{width:3.3});
      p.line([-2,s.t],[2,s.t],accepted?C.teal:C.red,1.6,'6 4');
      p.line([s.x,0],[s.x,Math.max(s.t,top)],C.gray,1.3,'4 4');
      values.forEach((v,i)=>p.dot([s.x,v],[C.teal,C.violet,C.gold][i],v===top?5.2:4.2,true));
      p.dot([.25,1],C.blue,5,true);p.dot([s.x,s.t],accepted?C.teal:C.red,6);
      p.text([.25,1],'(¼, 1)',C.blue,11,18);
    },{x:'x',y:'残差 / t'}),{wide:true,legends:legend([M('|x-1|'),C.teal,true],[M('|2x+0.5|'),C.violet,true],
      [M('|-0.8x+1.2|'),C.gold,true],['逐点最大值',C.blue]),
      value:reading('t='+fmt(s.t),'f_0(x)='+fmt(top),'(r_1,r_2,r_3)='+vec(values))+'<span>'+(accepted?'可行':'不可行')+'</span>'});
  }),

  '09-2':model({a:-1,b:1.5},[
    range('a','左端点 x₁',-1.85,-.1,.01),range('b','右端点 x₂',.1,1.85,.01)
  ],s=>{
    const f=x=>x*x;
    function draw(epi) {
      const a=[s.a,f(s.a)+(epi?.43:0)],b=[s.b,f(s.b)+(epi?.34:0)];
      return panel(M(epi?'\\operatorname{epi}f':'\\operatorname{graph}f'),chart(epi?'抛物线的上图':'抛物线的函数图像',[-2,2,0,5],p=>{
        if(epi) {
          above(p,f,-2,2,5,C.blue);
          for(const x of [-.85,0,.85])p.arrow([x,4.2],[x,4.9],C.blue,1.7);
        }
        p.curve(f,-2,2,C.blue);
        p.line(a,b,epi?C.teal:C.red,2.65,'6 4');
        p.dot(a,C.blue,6,false,'a');p.dot(b,C.blue,6,false,'b');
      },{x:'x',y:'t'}),{key:epi?'epi':'graph',value:reading(epi?'t\\ge x^2':'t=x^2')});
    }
    return draw(false)+draw(true);
  },{drag:(_,key,p)=>key==='a'?{a:clamp(p[0],-1.85,-.1)}:key==='b'?{b:clamp(p[0],.1,1.85)}:null}),

  '09-3':model({x:0},[range('x','读数 x',-2.5,2.5,.02),preset('交点',{x:0})],s=>{
    const f=x=>(x-1)**2,g=x=>(x+1)**2;
    const draw=(upper)=>{
      const envelope=x=>Math[upper?'max':'min'](f(x),g(x));
      const name=upper?'逐点最大值 · 上图交集':'逐点最小值 · 上图并集';
      return panel(name,chart(name,[-2.5,2.5,0,12.5],p=>{
        above(p,envelope,-2.5,2.5,12.5,C.blue);
        p.curve(f,-2.5,2.5,C.teal,{dash:'5 4',width:1.8});
        p.curve(g,-2.5,2.5,C.violet,{dash:'5 4',width:1.8});
        p.curve(envelope,-2.5,2.5,C.blue,{width:3.5});
        p.line([s.x,0],[s.x,12.5],C.gray,1.3,'4 4');
        p.dot([s.x,envelope(s.x)],C.red,6);
      },{x:'x',y:'t'}),{legends:legend([M('(x-1)^2'),C.teal,true],[M('(x+1)^2'),C.violet,true]),
        value:reading((upper?'\\max':'\\min')+'\\{f_1,f_2\\}='+fmt(envelope(s.x)))});
    };
    return draw(true)+draw(false);
  }),

  '09-4':model({x:1.25,angle:35},[
    range('x','固定 x',-2,2,.02),range('angle','观察方向',-90,110,1),
    preset('原视角',{angle:35}),preset('谷底原点',{x:0})
  ],s=>{
    const f=(x,y)=>x*x+x*y+y*y/2,g=x=>x*x/2;
    const a=[s.x,0,f(s.x,0)],b=[s.x,-s.x,g(s.x)];
    const v=spatial('Schur 补的谷底与竖直截面',[[-2,2],[-2,2],[0,10]],{
      angle:s.angle,axes:['x','y','f'],
      cells:[...mesh((x,y)=>[x,y,f(x,y)],[-2,2],[-2,2],25,24,C.blue,.22),
        ...mesh((y,h)=>[s.x,y,h],[-2,2],[0,7],6,5,C.teal,.12)],
      segments:[
        {vertices:seq(-2,2,120).map(t=>[t,-t,g(t)]),color:C.teal,width:3.3},
        {vertices:seq(-2,2,120).map(y=>[s.x,y,f(s.x,y)]),color:C.violet,width:2.3},
        {vertices:seq(0,-s.x,65).map(y=>[s.x,y,f(s.x,y)]),color:C.gold,width:4}
      ],points:[{at:a,name:'y = 0'},{at:b,name:'谷底',color:C.teal,offset:[9,17]}]
    });
    return panel('曲面与固定 x 的竖直截面',v,{wide:true,legends:legend(['原曲面',C.blue],['谷底线',C.teal],['截面曲线',C.violet],['沿 y 移动',C.gold])})+
    panel('俯视等高线',chart('固定 x 与边际最小化',[-2,2,-2,2],p=>{
      for(const h of [.25,.7,1.4,2.4,4,6,8])
        p.path(seq(0,2*Math.PI,128).map(t=>{
          const x=Math.sqrt(2*h)*Math.cos(t);
          return [x,Math.sqrt(2*h)*Math.sin(t)-x];
        }),C.gray,{width:1.2});
      p.line([-2,2],[2,-2],C.teal,2.6,'5 3');
      p.line([s.x,-2],[s.x,2],C.violet,1.5,'4 4');
      p.arrow(a.slice(0,2),b.slice(0,2),C.gold,3);
      p.dot(a.slice(0,2),C.red);p.dot(b.slice(0,2),C.teal);
    },{x:'x',y:'y',equal:true}),{value:reading('y^\\star=-x='+fmt(-s.x))})+
    panel('固定 y = 0 与谷底高度',chart('两条高度曲线',[-2,2,0,4.5],p=>{
      p.curve(x=>f(x,0),-2,2,C.red);p.curve(g,-2,2,C.teal);
      p.line([s.x,0],[s.x,a[2]],C.gray,1.4,'4 4');p.dot([s.x,a[2]],C.red);p.dot([s.x,b[2]],C.teal);
    },{x:'x',y:'高度'}),{legends:legend([M('f(x,0)=x^2'),C.red],[M('g(x)=x^2/2'),C.teal]),value:reading('f(x,0)='+fmt(a[2]),'g(x)='+fmt(b[2]))});
  }),

  '10-1':model({t:1.4,v:.78,angle:37},[
    range('t','时间 t',.2,2.5,.02),range('v','速率 v',.15,.8,.01),range('angle','观察方向',-90,110,1),
    preset('t = 0.5',{t:.5}),preset('t = 1',{t:1}),preset('t = 2',{t:2}),preset('恢复视角',{angle:37})
  ],s=>{
    const width=t=>Math.min(2,Math.sqrt(8*t));
    const f=(x,t)=>x*x/t;
    const q=[s.t*s.v,s.t,s.t*s.v*s.v],base=[s.v,1,s.v*s.v];
    const cut=seq(-width(s.t),width(s.t),100).map(x=>[x,s.t,f(x,s.t)]);
    const view=spatial('透视曲面与时间切片',[[-2,2],[0,2.5],[0,8]],{
      axes:['x','t','z'],angle:s.angle,
      cells:[...mesh((u,t)=>[u*width(t),t,f(u*width(t),t)],[-1,1],[.2,2.5],23,30,C.blue,.19),
        ...mesh((x,z)=>[x,s.t,z],[-2,2],[0,8],6,6,C.teal,.085)],
      segments:[{vertices:cut,color:C.teal,width:3},
        {vertices:[[0,0,0],[.2*s.v,.2,.2*s.v*s.v]],color:C.gray,dash:'4 4'},
        {vertices:[[.2*s.v,.2,.2*s.v*s.v],[2.5*s.v,2.5,2.5*s.v*s.v]],color:C.gold,width:3.2}],
      points:[{at:base,name:'t = 1',color:C.gold,offset:[-37,17]},{at:q,name:'当前点',color:C.red}]
    });
    return panel('工作量、时间与总成本',view,{wide:true,legends:legend(['透视曲面',C.blue],['时间截线',C.teal],['同速率射线',C.gold]),
      value:reading('(x,t,z)='+vec(q),'v='+fmt(s.v))})+
    panel('不同时间的二维截面',chart('不同时间的成本抛物线',[-2,2,0,8.2],p=>{
      [.5,1,2].forEach((t,i)=>p.curve(x=>f(x,t),-2,2,[C.violet,C.gray,C.gold][i],{dash:'5 4',width:1.65}));
      p.curve(x=>f(x,s.t),-width(s.t),width(s.t),C.teal,{width:3});
      p.dot([q[0],q[2]],C.red);
    },{x:'x',y:'z'}),{wide:true,legends:legend(['t = 0.5',C.violet,true],['t = 1',C.gray,true],['t = 2',C.gold,true],['当前截面',C.teal])});
  }),

  '10-2':model({theta:.5},[
    range('theta','方案 1 的混合比例 θ',0,1,.01),preset('只用方案 2',{theta:0}),
    preset('对半混合',{theta:.5}),preset('只用方案 1',{theta:1})
  ],s=>{
    const a=[1,4],b=[3,6],p0=mix(b,a,s.theta),t=p0[0],v=p0[1]/t,w1=s.theta/t,w2=1-w1;
    return panel('工作量与时间的混合',chart('方案混合点与速率射线',[0,3.5,0,7.15],p=>{
      [2,4].forEach((v,i)=>p.line([0,0],[3.5,3.5*v],[C.teal,C.blue][i],1.5,'5 5'));
      p.line([0,0],p0,C.gold,2.75);
      p.line(a,b,C.gray,2,'5 4');p.dot(a,C.blue);p.dot(b,C.teal);p.dot(p0,C.red,6);
      p.text(a,'方案 1',C.blue,-45,-11);p.text(b,'方案 2',C.teal,-58,20);
    },{x:'t',y:'x'}),{value:bars([['θt₁',s.theta,C.blue],['(1−θ)t₂',3*(1-s.theta),C.teal]])+
      reading('w_1='+fmt(w1),'w_2='+fmt(w2))})+
    panel('速率权重与凸函数弦',chart('速率平方与混合权重',[1.6,4.4,2,18],p=>{
      p.curve(v=>v*v,1.6,4.4,C.blue);
      p.line([2,4],[4,16],C.gray,2,'5 5');
      p.dot([2,4],C.teal);p.dot([4,16],C.blue);
      p.line([v,v*v],[v,16*w1+4*w2],C.gold,2);
      p.dot([v,v*v],C.red);p.dot([v,16*w1+4*w2],C.gold,4.7,true);
    },{x:'v',y:'f(v)'}),{value:reading('v=w_1v_1+w_2v_2='+fmt(v),'f(v)='+fmt(v*v),'w_1 f(v_1)+w_2 f(v_2)='+fmt(16*w1+4*w2))});
  }),

  '10-3':model({a1:1,a2:9},[
    range('a1','任务 1 的 a₁',.5,16,.5),range('a2','任务 2 的 a₂',.5,16,.5)
  ],s=>{
    const {a1,a2}=s,f=t=>a1/t,g=t=>a2/(10-t),F=t=>f(t)+g(t);
    const t=10*Math.sqrt(a1)/(Math.sqrt(a1)+Math.sqrt(a2)),m=10*a1/(a1+a2),slope=a1/t**2;
    const high=Math.max(3.3,F(t)*2.3,F(m)*1.12);
    return panel('两项成本与总成本',chart('时间分配与最优平衡点',[0,10,0,high],p=>{
      p.curve(f,.015,9.985,C.teal,{dash:'5 4',width:1.85});
      p.curve(g,.015,9.985,C.violet,{dash:'5 4',width:1.85});p.curve(F,.015,9.985,C.blue,{width:3});
      p.line([t-.9,f(t)+.9*slope],[t+.9,f(t)-.9*slope],C.teal,2.6);
      p.line([t-.9,g(t)-.9*slope],[t+.9,g(t)+.9*slope],C.violet,2.6);
      p.dot([m,F(m)],C.gold,5,true);p.dot([t,F(t)],C.red,6);
      p.text([m,F(m)],'按 a 分配',C.gold,m>7?-73:11,-10);
      p.text([t,F(t)],'最优',C.red,12,20);
    },{x:'t₁',y:'成本'}),{wide:true,legends:legend([M('a_1/t_1'),C.teal,true],[M('a_2/(10-t_1)'),C.violet,true],['总成本',C.blue]),
      value:reading('t_1^\\star='+fmt(t),'t_2^\\star='+fmt(10-t),'F(t_1^\\star)='+fmt(F(t)),'f_1^{\\prime}='+fmt(-slope),'f_2^{\\prime}='+fmt(slope))});
  }),

  '11-1':model({t:-.5},[
    range('t','水位 τ',-1.5,2,.01),preset('双阱空集',{t:-1.25}),preset('双阱双区间',{t:-.5}),preset('双阱单区间',{t:.4})
  ],s=>{
    const t=s.t;
    const roots=t>=-1?[Math.sqrt(Math.max(0,1-Math.sqrt(1+t))),Math.sqrt(1+Math.sqrt(1+t))]:[];
    const a=t>=0?Math.sqrt(t):0;
    const specs=[
      [M('x^2'),x=>x*x,[-2,2,-1.7,3.55],t<0?[]:[[-a,a]],false],
      [M('\\log x'),Math.log,[0,8,-2.6,2.5],[[0,Math.exp(t)]],true],
      [M('x^4-2x^2'),x=>x**4-2*x*x,[-1.8,1.8,-1.7,3.55],
        !roots.length?[]:t>=0?[[-roots[1],roots[1]]]:[[-roots[1],-roots[0]],[roots[0],roots[1]]],false],
    ];
    return specs.map(([name,f,bounds,intervals,isLog])=>{
      const [lo,hi,low,high]=bounds;
      return panel(name,chart('水位切片和次水平集',bounds,p=>{
        p.curve(f,isLog?.002:lo,hi,C.blue);
        p.line([lo,t],[hi,t],C.gold,2,'5 4');
        for(const [u,v] of intervals) {
          p.line([u,0],[v,0],C.teal,5);
          p.dot([u,0],C.teal,5,isLog);
          p.dot([v,0],C.teal,5);
          if(!isLog)p.dot([u,t],C.gold,4.2,true);
          p.dot([v,t],C.gold,4.2,true);
        }
      },{x:'x',y:'f(x)'}),{value:reading('\\tau='+fmt(t),
        'S_\\tau='+(!intervals.length?'\\varnothing':intervals.map(([u,v])=>(isLog?'(':'[')+fmt(u)+','+fmt(v)+']').join('\\cup')))});
    }).join('');
  }),

  '11-2':model({x:-.65},[range('x','探测点 x',-1,1,.02),preset('原点',{x:0})],s=>{
    return panel(M('f(x)=\\min\\{x,0\\}'),chart('平坦段的局部最小与更低点',[-1,1,-1.1,.45],p=>{
      p.area([[.25,-1.1],[.75,-1.1],[.75,.45],[.25,.45]],C.teal,.13);
      p.curve(x=>Math.min(x,0),-1,1,C.blue);
      p.dot([.5,0],C.teal);p.text([.5,0],'x₀ = 0.5',C.teal,-28,-11);
      p.dot([-1,-1],C.red,5);p.text([-1,-1],'更低点',C.red,8,-9);
      p.dot([s.x,Math.min(s.x,0)],C.gold,5,true);
    },{x:'x',y:'f(x)'}),{value:reading('x='+fmt(s.x),'f(x)='+fmt(Math.min(s.x,0)))})+
    panel(M('f(x)=x^3'),chart('拐点的水平切线与更低点',[-1.5,1.5,-3.5,3.5],p=>{
      p.curve(x=>x**3,-1.5,1.5,C.blue);p.line([-1.5,0],[1.5,0],C.teal,2,'5 5');
      p.dot([0,0],C.teal);p.text([0,0],'f′(0) = 0',C.teal,10,-12);
      p.dot([-1,-1],C.red);p.text([-1,-1],'更低点',C.red,-27,19);
      p.dot([s.x,s.x**3],C.gold,5,true);
    },{x:'x',y:'f(x)'}),{value:reading('x='+fmt(s.x),'f(x)='+fmt(s.x**3))});
  }),

  '11-3':model({t:.7,k:0,mode:'level'},[
    range('t','候选门槛 τ',.3,1.4,.01),choice('mode','查看方式',[['level','移动门槛'],['algorithm','二分追踪']]),
    preset('可行门槛',{t:.7,mode:'level'}),preset('最优门槛',{t:.5,mode:'level'}),preset('不可行门槛',{t:.45,mode:'level'}),
    preset('二分一步',s=>({mode:'algorithm',k:Math.min(23,s.k+1)})),preset('初始区间',{mode:'algorithm',k:0})
  ],s=>{
    const {low,high,mid,witness}=bisect(s.k),t=s.mode==='algorithm'?mid:s.t;
    function slice(t,compare=false) {
      const feasible=thresholdSet(t),name=compare?'门槛对照':'当前门槛的可行切片';
      return panel(name,chart(name,[-.35,4.35,-.35,4.35],p=>{
        p.path(poly,C.gray,{close:true,width:1.9});p.area(poly,C.gray,.10);
        thresholdPlanes(t).forEach(([a,b],i)=>boundary(p,a,b,[C.violet,C.gold][i],'5 4'));
        if(feasible.length){
          p.area(feasible,C.blue,.25);p.path(feasible,C.blue,{close:true,width:2.7});
          p.dot(times(feasible.reduce(plus,[0,0]),1/feasible.length),C.teal,5.5);
        }
      },x2y),{value:reading('\\tau='+fmt(t,5))+'<span>'+(feasible.length?'可行':'空集')+'</span>'});
    }
    const x=v=>45+345*(v-.3)/1.1;
    const interval=svg('拟凸二分的区间与见证',440,125,
      line([45,53],[390,53],C.grid,2)+line([x(low),53],[x(high),53],C.blue,5)+
      point([x(low),53],C.red,5,true)+point([x(high),53],C.teal,5)+point([x(mid),53],C.gold,5)+
      text([52,96],'下界 '+fmt(low,6),C.red,{size:15})+text([235,96],'上界 '+fmt(high,6),C.teal,{size:15}));
    return slice(t)+slice(t<.5?.7:.45,true)+panel('二分区间与可行见证',interval,
      {wide:true,value:reading('k='+s.k,'[\\ell,u]=['+fmt(low,6)+','+fmt(high,6)+']','x_u='+vec(witness,6))});
  }),
};

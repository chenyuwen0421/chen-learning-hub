import {C, arrow, line, norm, path, plus, minus, point, seq, svg, text, times} from './plot.mjs';

export function mesh(fn, u, v, m=24, n=18, color=C.blue, opacity=.19) {
  const grid = seq(u[0],u[1],m).map(s=>seq(v[0],v[1],n).map(t=>fn(s,t)));
  const cells = [];
  for(let i=0;i<m;i++) for(let j=0;j<n;j++) {
    const vertices = [grid[i][j],grid[i+1][j],grid[i+1][j+1],grid[i][j+1]];
    if(vertices.every(p=>p?.every(Number.isFinite))) {
      cells.push({vertices,color,opacity:opacity*(.7+.55*j/n)});
    }
  }
  return cells;
}
export function spatial(title, bounds, {cells=[], segments=[], points=[], labels=[], axes=['x₁','x₂','z'], angle=36, tilt=31, width=460,height=350}={}) {
  const radians=Math.PI/180, a=angle*radians, e=tilt*radians;
  const rotate=([x,y,z])=>[Math.cos(a)*x-Math.sin(a)*y,
    Math.sin(e)*(Math.sin(a)*x+Math.cos(a)*y)-Math.cos(e)*z,
    Math.cos(e)*(Math.sin(a)*x+Math.cos(a)*y)+Math.sin(e)*z];
  const corners=bounds[0].flatMap(x=>bounds[1].flatMap(y=>bounds[2].map(z=>rotate([x,y,z]))));
  const span=[0,1].map(i=>[Math.min(...corners.map(p=>p[i])),Math.max(...corners.map(p=>p[i]))]);
  const scale=Math.min((width-82)/(span[0][1]-span[0][0]),(height-60)/(span[1][1]-span[1][0]));
  const origin=span.map(([min,max],i)=>[width/2,height/2][i]-scale*(min+max)/2);
  const P=world=>plus(times(rotate(world).slice(0,2),scale),origin);
  const axisOrigin=bounds.map(([lo,hi])=>Math.min(hi,Math.max(lo,0)));
  const floor=bounds[2][0], [[x0,x1],[y0,y1]]=bounds;
  let background='';
  for(const x of seq(x0,x1,6)) background+=line(P([x,y0,floor]),P([x,y1,floor]),C.grid,1);
  for(const y of seq(y0,y1,6)) background+=line(P([x0,y,floor]),P([x1,y,floor]),C.grid,1);
  let geometry = cells.map(cell=>({...cell,depth:cell.vertices.reduce((s,p)=>s+rotate(p)[2],0)/cell.vertices.length}))
    .sort((a,b)=>b.depth-a.depth).map(({vertices,color,opacity})=>
      path(vertices.map(P),color,{fill:color,close:true,width:.65,opacity})).join('');
  let wires='';
  for(const {vertices,color=C.blue,width:w=2.5,dash='',arrowhead=false} of segments) {
    if(arrowhead && vertices.length===2) wires+=arrow(P(vertices[0]),P(vertices[1]),color,w,dash);
    else wires+=path(vertices.map(P),color,{width:w,dash});
  }
  let axisMarkup='';
  axes.forEach((label,i)=>{
    const start=axisOrigin.slice(), end=axisOrigin.slice();
    [start[i],end[i]]=bounds[i];
    axisMarkup+=arrow(P(start),P(end),C.gray,1.25)+text(plus(P(end),[7,-7]),label,C.ink);
  });
  const annotations=points.map(({at,color=C.red,name='',open=false,offset=[8,-9]})=>
    point(P(at),color,5.4,open)+(name?text(plus(P(at),offset),name,color):'')).join('')+
    labels.map(({at,name,color=C.ink,offset=[4,-9]})=>text(plus(P(at),offset),name,color)).join('');
  return svg(title,width,height,background+geometry+axisMarkup+wires+annotations);
}

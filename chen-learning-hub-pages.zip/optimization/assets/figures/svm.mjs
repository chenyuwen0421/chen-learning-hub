import {dot, minus, plus, times} from './plot.mjs';

// For the reflected pairs (p,+1) and (-p,-1), convexity and reflection give an optimum with b=0.
export const positive = [[2.25,.67],[1.25,-.72],[.42,.56],[-.64,.31]];
export function softMargin(C) {
  const value = w => dot(w,w)/2 + 2*C*positive.reduce((s,p)=>s+Math.max(0,1-dot(w,p)),0);
  let w = [0,0], best = value(w);
  const consider = candidate => {
    const score=value(candidate);
    if(score<best-1e-12) {w=candidate;best=score;}
  };
  // On each hinge cell, the objective is quadratic plus a linear term.
  // The minimum is its free minimizer, a projection onto one active line, or a vertex.
  for(let mask=0; mask<(1<<positive.length); mask++) {
    const sum = positive.reduce((v,p,i)=>mask&(1<<i) ? plus(v,p) : v,[0,0]);
    const free=times(sum,2*C);
    consider(free);
    for(const p of positive) consider(plus(free,times(p,(1-dot(free,p))/dot(p,p))));
  }
  for(let i=0;i<positive.length;i++) for(let j=i+1;j<positive.length;j++) {
    const [a,b]=positive[i],[c,d]=positive[j],det=a*d-b*c;
    if(Math.abs(det)>1e-10)consider([(d-b)/det,(a-c)/det]);
  }
  const slack = positive.map(p=>Math.max(0,1-dot(w,p)));
  return {w,b:0,slack,value:best};
}

export function hardPair(positive,negative) {
  const delta=minus(positive,negative), w=times(delta,2/dot(delta,delta));
  return {w,b:-dot(w,times(plus(positive,negative),.5))};
}
